import {
  EditingState,
  ICollection,
  useCollectionQuery,
  ViewType,
  initialCategoryStates
} from '@pro3/DynamicForm'
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { CollectionsContext } from './CollectionsContext'
import {
  getStoredCollectionFromSessionStorage,
  setCollectionInSessionStorage,
  getFromSessionStorage,
  setInSessionStorage,
  SESSION_STORAGE_KEYS
} from '../../utils/sessionStorage'

const CollectionsProvider = ({ children }: { children: React.ReactNode }) => {
  const { data: collections, isLoading } = useCollectionQuery()

  // Initialize selectedCollection from session storage
  const [selectedCollection, setSelectedCollectionState] = useState<ICollection | null>(null)

  // Initialize editingState from session storage
  const [editingState, setEditingStateInternal] = useState<EditingState>(() => {
    const savedEditingState = getFromSessionStorage<EditingState>(
      SESSION_STORAGE_KEYS.EDITING_STATE
    )
    const defaultEditingState: EditingState = {
      editingField: null,
      editingRow: null,
      hoveredItem: null,
      editingOption: null,
      editingCondition: null,
      currentView: ViewType.Rows,
      categoryStates: initialCategoryStates
    }

    // Merge saved state with default state to ensure all properties exist
    return savedEditingState
      ? { ...defaultEditingState, ...savedEditingState }
      : defaultEditingState
  })

  // Wrapper function for setSelectedCollection that also saves to session storage
  const setSelectedCollection = useCallback(
    (collection: ICollection | null | ((prev: ICollection | null) => ICollection | null)) => {
      setSelectedCollectionState((prev) => {
        const newCollection = typeof collection === 'function' ? collection(prev) : collection
        // Save to session storage (excluding schema)
        setCollectionInSessionStorage(newCollection)
        return newCollection
      })
    },
    []
  )

  // Wrapper function for setEditingState that also saves to session storage
  const setEditingState = useCallback((newEditingState: EditingState) => {
    setEditingStateInternal(newEditingState)

    setInSessionStorage(SESSION_STORAGE_KEYS.EDITING_STATE, {
      ...newEditingState,
      hoveredItem: null
    })
  }, [])

  // Function to reconstruct a collection with its schema from the available collections
  const reconstructCollectionSchema = useCallback(
    (storedCollection: { name: string }) => {
      if (!collections) return null
      return (collections.find((c) => c.name === storedCollection.name) || null)?.schema
    },
    [collections]
  )

  const previewCollection: ICollection | undefined = useMemo(() => {
    if (!selectedCollection) return undefined

    return selectedCollection
  }, [selectedCollection])

  useEffect(() => {
    if (collections && collections.length > 0) {
      // Check if we have a stored collection from session storage
      const storedCollection = getStoredCollectionFromSessionStorage()

      if (storedCollection) {
        // Try to reconstruct the collection with its schema
        const schema = reconstructCollectionSchema(storedCollection)
        if (schema) {
          // Only set if it's different from current selection
          if (!selectedCollection || selectedCollection.name !== storedCollection.name) {
            setSelectedCollectionState({ ...storedCollection, schema })
          }
        } else {
          // Stored collection no longer exists, select the first one
          setSelectedCollection(collections[0])
        }
      } else if (!selectedCollection) {
        // No stored collection and no selected collection, select the first one
        setSelectedCollection(collections[0])
      }
    }
  }, [collections, reconstructCollectionSchema, selectedCollection, setSelectedCollection])

  return (
    <CollectionsContext.Provider
      value={{
        collections,
        isLoading,
        selectedCollection,
        setSelectedCollection,
        editingState,
        setEditingState,
        previewCollection
      }}
    >
      {children}
    </CollectionsContext.Provider>
  )
}

export default CollectionsProvider
