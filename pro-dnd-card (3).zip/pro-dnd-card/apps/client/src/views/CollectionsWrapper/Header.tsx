import { Box, IconButton, Stack, Tooltip, Typography, Button } from '@mui/material'
import { Select } from '@mui/material'
import { MenuItem } from '@mui/material'
import EditIcon from '@mui/icons-material/Edit'
import RefreshIcon from '@mui/icons-material/Refresh'
import { openUiSchemaEditorDialog } from '@pro3/DynamicForm'
import { useContext } from 'react'
import { CollectionsContext } from './CollectionsContext'
import { clearAppSessionStorage } from '../../utils/sessionStorage'

const Header = ({ title }: { title: string }) => {
  const { selectedCollection, setSelectedCollection, collections, isLoading } =
    useContext(CollectionsContext)

  const handleOpenJsonEditor = async () => {
    try {
      if (!selectedCollection) return

      const uiSchemaResult = await openUiSchemaEditorDialog({
        uiSchema: selectedCollection.uiSchema
      })

      if (uiSchemaResult) {
        setSelectedCollection({ ...selectedCollection, uiSchema: uiSchemaResult })
      }
    } catch {
      // User cancelled the dialog
    }
  }

  const onChangeCollection = (collectionName: string) => {
    const collection = collections?.find((c) => c.name === collectionName)

    if (collection) {
      setSelectedCollection(collection)
    }
  }

  const onHardReload = () => {
    // Clear all session storage
    clearAppSessionStorage()

    // Reload the page to reset all state
    window.location.reload()
  }

  return (
    <Stack
      direction='row'
      spacing={2}
      alignItems='center'
      p={2}
      border='1px solid'
      borderColor='divider'
    >
      <Typography variant='h5'>{title}</Typography>

      <Tooltip title='עריכת סכמת UI'>
        <IconButton size='small' onClick={handleOpenJsonEditor}>
          <EditIcon />
        </IconButton>
      </Tooltip>

      <Tooltip title='Hard Reload - Clear all data and reset'>
        <Button
          variant='outlined'
          size='small'
          startIcon={<RefreshIcon />}
          onClick={onHardReload}
          sx={{
            color: 'error.main',
            borderColor: 'error.main',
            '&:hover': {
              borderColor: 'error.dark',
              backgroundColor: 'error.light',
              color: 'error.dark'
            }
          }}
        >
          Hard Reload
        </Button>
      </Tooltip>

      <Box sx={{ flex: 1 }} />

      <Select
        size='small'
        value={isLoading ? 'loading' : (selectedCollection?.name ?? '')}
        onChange={(e) => onChangeCollection(e.target.value)}
        disabled={isLoading}
        sx={{ minWidth: 200, backgroundColor: 'background.default' }}
      >
        {isLoading ? (
          <MenuItem value='loading' disabled>
            Loading...
          </MenuItem>
        ) : (
          (collections ?? []).map((c) => (
            <MenuItem key={c.name} value={c.name}>
              {c.name}
            </MenuItem>
          ))
        )}
      </Select>
    </Stack>
  )
}

export default Header
