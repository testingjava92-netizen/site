// import PendingActionsIcon from '@mui/icons-material/PendingActions'

// import { translate } from 'utils/translate'

import DynamicFormView from '@pro3/client/src/views/DynamicFormView'
import { initialData as cardLoader } from '../DynamicFormView/loader'

import DynamicFormIcon from '@mui/icons-material/DynamicForm'

import { RouteObject } from 'react-router'
import DNDCard from '../DNDCard'

type routeInfo = {
  label: string
  icon: JSX.Element
  showInHeader?: boolean
}

export const routes: (routeInfo & RouteObject)[] = [
  {
    index: true,
    label: 'DynamicForm',
    path: '/DynamicForm',
    icon: <DynamicFormIcon />,
    Component: DynamicFormView,
    loader: cardLoader
  },
  {
    label: 'DNDCard',
    path: '/DNDCard',
    icon: <DynamicFormIcon />,
    Component: DNDCard,
    loader: cardLoader
  }
]
