import { IconType, FieldComponentType, LazyLoaderType, SizeKey } from '../types/enums'
import { IOption, FieldComponentMapper } from '../types/types'
import {
  Check,
  Warning,
  Info,
  Close,
  Add,
  CalendarToday,
  Save,
  Delete,
  Edit,
  Search,
  CheckCircle,
  LocationOn,
  Phone,
  Email,
  Home,
  Person,
  Settings,
  Cancel,
  Error,
  CarCrash,
  DirectionsBike,
  DirectionsRun,
  SvgIconComponent
} from '@mui/icons-material'

// Component imports
import LayoutTextField from '../components/Field/components/LayoutTextField'
import LayoutSelect from '../components/Field/components/LayoutSelect'
import LayoutButtonsGroup from '../components/Field/components/LayoutButtonsGroup'
import LayoutCheckbox from '../components/Field/components/LayoutCheckbox'
import LayoutSwitch from '../components/Field/components/LayoutSwitch'
import LayoutDateRangePicker from '../components/Field/components/LayoutDateRangePicker'
import LayoutDatePicker from '../components/Field/components/LayoutDatePicker'
import LayoutDateTimePicker from '../components/Field/components/LayoutDateTimePicker'
import LayoutChipsSelect from '../components/Field/components/LayoutChipsSelect'
import LayoutRadio from '../components/Field/components/LayoutRadio'
import LayoutSlider from '../components/Field/components/LayoutSlider'
import { QueryClient } from '@tanstack/react-query'

// Icon mapper for converting IconType enum to React components
export const iconMap: Record<IconType, SvgIconComponent> = {
  [IconType.HOME]: Home,
  [IconType.SETTINGS]: Settings,
  [IconType.PERSON]: Person,
  [IconType.EMAIL]: Email,
  [IconType.PHONE]: Phone,
  [IconType.LOCATION]: LocationOn,
  [IconType.CALENDAR]: CalendarToday,
  [IconType.SEARCH]: Search,
  [IconType.ADD]: Add,
  [IconType.EDIT]: Edit,
  [IconType.DELETE]: Delete,
  [IconType.SAVE]: Save,
  [IconType.CANCEL]: Cancel,
  [IconType.CHECK]: Check,
  [IconType.CLOSE]: Close,
  [IconType.INFO]: Info,
  [IconType.WARNING]: Warning,
  [IconType.ERROR]: Error,
  [IconType.SUCCESS]: CheckCircle,
  [IconType.CAR]: CarCrash,
  [IconType.BICYCLE]: DirectionsBike,
  [IconType.LEGS]: DirectionsRun
}

// Height mapper for converting SizeKey enum to CSS height values
// Base height: 56px, each step adds 4px
export const heightMap: Record<SizeKey, string> = {
  [SizeKey.S0]: '44px', // Base
  [SizeKey.S1]: '48px', // +4px
  [SizeKey.S2]: '52px', // +8px
  [SizeKey.S3]: '56px', // +12px
  [SizeKey.S4]: '60px', // +16px
  [SizeKey.S5]: '64px', // +20px
  [SizeKey.S6]: '68px', // +24px
  [SizeKey.S7]: '72px', // +28px
  [SizeKey.S8]: '76px', // +32px
  [SizeKey.S9]: '80px', // +36px
  [SizeKey.S10]: '84px', // +40px
  [SizeKey.S11]: '88px', // +44px
  [SizeKey.S12]: '92px', // +48px
  [SizeKey.S13]: '96px', // +52px
  [SizeKey.S14]: '100px', // +56px
  [SizeKey.S15]: '104px', // +60px
  [SizeKey.S16]: '108px', // +64px
  [SizeKey.S17]: '112px', // +68px
  [SizeKey.S18]: '116px', // +72px
  [SizeKey.S19]: '120px', // +76px
  [SizeKey.S20]: '124px', // +80px
  [SizeKey.S21]: '128px', // +84px
  [SizeKey.S22]: '132px', // +88px
  [SizeKey.S23]: '136px', // +92px
  [SizeKey.S24]: '140px', // +96px
  [SizeKey.S25]: '144px', // +100px
  [SizeKey.S26]: '148px', // +104px
  [SizeKey.S27]: '152px', // +108px
  [SizeKey.S28]: '156px', // +112px
  [SizeKey.S29]: '160px', // +116px
  [SizeKey.S30]: '164px', // +120px
  [SizeKey.S31]: '168px', // +124px
  [SizeKey.S32]: '172px', // +128px
  [SizeKey.S33]: '176px', // +132px
  [SizeKey.S34]: '180px', // +136px
  [SizeKey.S35]: '184px', // +140px
  [SizeKey.S36]: '188px', // +144px
  [SizeKey.S37]: '192px', // +148px
  [SizeKey.S38]: '196px', // +152px
  [SizeKey.S39]: '200px', // +156px
  [SizeKey.S40]: '204px' // +160px
}

export const componentMap: FieldComponentMapper = {
  [FieldComponentType.inputText]: LayoutTextField,
  [FieldComponentType.inputNumber]: LayoutTextField,
  [FieldComponentType.inputEmail]: LayoutTextField,
  [FieldComponentType.inputPassword]: LayoutTextField,
  [FieldComponentType.inputUrl]: LayoutTextField,
  [FieldComponentType.textarea]: LayoutTextField,
  [FieldComponentType.inputDate]: LayoutDatePicker,
  [FieldComponentType.inputDateTime]: LayoutDateTimePicker,
  [FieldComponentType.inputDateRange]: LayoutDateRangePicker,
  [FieldComponentType.inputSlider]: LayoutSlider,
  [FieldComponentType.select]: LayoutSelect,
  [FieldComponentType.chipsSelect]: LayoutChipsSelect,
  [FieldComponentType.inputCheckbox]: LayoutCheckbox,
  [FieldComponentType.inputSwitch]: LayoutSwitch,
  [FieldComponentType.buttonsGroup]: LayoutButtonsGroup,
  [FieldComponentType.inputRadio]: LayoutRadio
}

type LazyLoaderFunction = (queryClient: QueryClient) => Promise<IOption[]>

export const loadDepartments = (queryClient: QueryClient) => {
  console.log('getLoadDepartments', queryClient)

  return queryClient.fetchQuery({
    queryKey: ['departments'],
    queryFn: async () => {
      console.log('LOAD_DEPARTMENTS')

      await new Promise((resolve) => setTimeout(resolve, 300))

      console.log('LOAD_DEPARTMENTS_DONE')

      return [
        { value: 'engineering', label: 'הנדסה' },
        { value: 'marketing', label: 'שיווק' },
        { value: 'sales', label: 'מכירות' }
      ]
    },
    staleTime: Infinity
  })
}

export const loadPirates = (queryClient: QueryClient) => {
  return queryClient.fetchQuery({
    queryKey: ['pirates'],
    queryFn: async () => {
      await new Promise((resolve) => setTimeout(resolve, 300))
      return [
        { value: 'pirate1', label: 'פיראט 1' },
        { value: 'pirate2', label: 'פיראט 2' },
        { value: 'pirate3', label: 'פיראט 3' }
      ]
    },
    staleTime: Infinity
  })
}

export const lazyLoaderMap: Record<LazyLoaderType, LazyLoaderFunction> = {
  [LazyLoaderType.LOAD_DEPARTMENTS]: loadDepartments,
  [LazyLoaderType.LOAD_PIRATES]: loadPirates
}
