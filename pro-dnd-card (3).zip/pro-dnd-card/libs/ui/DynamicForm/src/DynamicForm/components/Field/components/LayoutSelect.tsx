import { useState, useEffect, useMemo } from 'react'
import { FormControl, TextField, MenuItem, MenuList } from '@mui/material'
import Autocomplete from '@mui/material/Autocomplete'
import { useFormContext, Controller } from 'react-hook-form'
import { ISelectLayoutField, IOption, FieldComponentProps } from '../../../types'
import { lazyLoaderMap } from '../../../constants/mappers'
import { useQueryClient } from '@tanstack/react-query'
import { keyBy } from 'lodash'
import { evaluateCondition } from '../../../utils/utils'
import { useCardContext } from '../../../hooks/useCardContext'

const LayoutSelect = ({
  field,
  rowHeight,
  disabled = false
}: FieldComponentProps<ISelectLayoutField>) => {
  const { path, label, options, multiple, required, placeholder } = field
  const { control, watch } = useFormContext()
  const { collection } = useCardContext()
  const formValues = watch()
  const [loadedOptions, setLoadedOptions] = useState<IOption[]>(options?.values || [])
  const [loading, setLoading] = useState(false)
  const queryClient = useQueryClient()

  useEffect(() => {
    if (options?.lazyValues && !options.values) {
      setLoading(true)
      const loaderFunction = lazyLoaderMap[options.lazyValues]
      if (loaderFunction) {
        loaderFunction(queryClient)
          .then((data) => {
            setLoadedOptions(data)
          })
          .catch((error) => {
            console.error('Error loading options:', error)
            setLoadedOptions([])
          })
          .finally(() => {
            setLoading(false)
          })
      } else {
        console.error(`Lazy loader not found for key: ${options.lazyValues}`)
        setLoading(false)
      }
    }
  }, [options, queryClient])

  // Filter options based on hidden/disabled conditions
  const currentOptions = useMemo(() => {
    return loadedOptions.filter((option) => {
      const isHidden = evaluateCondition(option.hidden, formValues, collection.uiSchema.context)
      return !isHidden
    })
  }, [loadedOptions, formValues, collection.uiSchema.context])
  const optionsMap = useMemo(() => keyBy(currentOptions, (o) => String(o.value)), [currentOptions])

  const getSelectedOptions = (value: unknown): IOption[] | IOption | null => {
    if (multiple) {
      const arr = (value || []) as Array<IOption['value']>
      const selected = arr.map((v) => optionsMap[String(v)]).filter(Boolean) as IOption[]
      return selected
    }
    const single = value as IOption['value'] | undefined
    if (single === undefined || single === null || single === '' || currentOptions.length === 0) {
      return null
    }
    return optionsMap[String(single)] ?? null
  }

  return (
    <Controller
      name={path}
      control={control}
      render={({ field, fieldState: { error } }) => {
        return (
          <FormControl fullWidth error={!!error} required={required}>
            <Autocomplete
              options={currentOptions}
              multiple={Boolean(multiple)}
              disableCloseOnSelect={Boolean(multiple)}
              loading={loading}
              disabled={disabled}
              slots={{ listbox: MenuList }}
              getOptionLabel={(option) => option.label}
              isOptionEqualToValue={(opt, val) => String(opt.value) === String(val.value)}
              value={getSelectedOptions(field.value) as IOption[] | IOption | null}
              slotProps={{
                paper: {
                  sx: (theme) => ({
                    bgcolor: 'background.default',
                    border: `1px solid ${theme.palette.divider}`,
                    boxShadow: theme.shadows[1]
                  })
                },
                listbox: {
                  sx: () => ({
                    p: 0,
                    bgcolor: 'background.default'
                  })
                }
              }}
              renderOption={({ key, ...props }, option, state) => {
                const isDisabled = evaluateCondition(
                  option.disabled,
                  formValues,
                  collection.uiSchema.context
                )
                return (
                  <MenuItem key={key} {...props} selected={state.selected} disabled={isDisabled}>
                    {option.label}
                  </MenuItem>
                )
              }}
              onChange={(_, newValue) => {
                if (multiple) {
                  const values = (newValue as IOption[]).map((o) => o.value)
                  field.onChange(values)
                } else {
                  const val = (newValue as IOption | null)?.value ?? ''
                  field.onChange(val)
                }
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={label}
                  placeholder={!multiple ? placeholder : undefined}
                  error={!!error}
                  helperText={error?.message}
                  disabled={disabled}
                  required={required}
                  sx={{
                    height: rowHeight
                  }}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      sx: {
                        height: '100%'
                      }
                    },
                    inputLabel: {
                      ...params.InputLabelProps,
                      shrink: true
                    }
                  }}
                />
              )}
              noOptionsText='לא נמצאו תוצאות'
              loadingText='טוען...'
            />
          </FormControl>
        )
      }}
    />
  )
}

export default LayoutSelect
