import { Box } from '@mui/material'
import { Field } from '../../Field/Field'
import { useFormContext } from 'react-hook-form'
import { evaluateCondition } from '../../../utils/utils'
import { DEFAULT_GAP } from '../../../../DNDCardBuilder/constants'
import { useCardContext } from '../../../hooks/useCardContext'
import EmptyRow from './EmptyRow'
import { ILayoutField } from '../../../types'

export interface RowContentProps {
  disabled?: boolean
  rowIndex: number
  rowHeight: string
}

export const RowContent = ({ rowIndex, rowHeight, disabled = false }: RowContentProps) => {
  const { collection } = useCardContext()
  const row = collection.uiSchema.rows[rowIndex]

  const fields: ILayoutField[] = (row?.fields ?? []) satisfies ILayoutField[]

  const gap = row?.gap ?? DEFAULT_GAP
  const { watch } = useFormContext()
  const formValues = watch()
  const isEmpty = !(fields.length > 0)

  return isEmpty ? (
    <EmptyRow row={row} rowIndex={rowIndex} rowHeight={rowHeight} />
  ) : (
    <Box
      data-row-index={rowIndex}
      sx={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'flex-start',
        gap: gap ? gap : undefined,
        '& > *': {
          display: 'flex',
          flexDirection: 'column',
          height: '100%'
        },
        alignItems: 'flex-start'
      }}
    >
      {fields.map((field, fieldIndex) => {
        const isFieldHidden = evaluateCondition(
          field.hidden,
          formValues,
          collection.uiSchema.context
        )

        if (isFieldHidden) {
          return null
        }

        const isFieldDisabled =
          disabled || evaluateCondition(field.disabled, formValues, collection.uiSchema.context)

        return (
          <Field
            key={field._id}
            field={field}
            fieldIndex={fieldIndex}
            rowIndex={rowIndex}
            rowHeight={rowHeight}
            disabled={isFieldDisabled}
          />
        )
      })}
    </Box>
  )
}

export default RowContent
