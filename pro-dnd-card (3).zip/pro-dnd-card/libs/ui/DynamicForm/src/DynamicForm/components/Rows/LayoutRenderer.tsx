import React, { useEffect } from 'react'
import { Box } from '@mui/material'
import { useFormContext } from 'react-hook-form'
import { evaluateCondition } from '../../utils/utils'
import { useCardContext } from '../../hooks/useCardContext'
import {
  DEFAULT_GAP,
  DEFAULT_PX,
  DEFAULT_PY,
  DEFAULT_ROW_HEIGHT
} from '../../../DNDCardBuilder/constants'
import Row from '../Row/Row'

export const LayoutRenderer: React.FC = () => {
  const contextvalue = useCardContext()
  const { watch } = useFormContext()
  const formValues = watch()

  const {
    collection: {
      uiSchema: {
        rows,
        gap = DEFAULT_GAP,
        px = DEFAULT_PX,
        py = DEFAULT_PY,
        rowHeight = DEFAULT_ROW_HEIGHT,
        context
      }
    },
    editingState
  } = contextvalue

  useEffect(() => {
    if (!editingState) return

    let elementToScrollTo: HTMLElement | null = null

    if (editingState.editingField) {
      const fieldId = rows?.[editingState.editingField.rowIndex]?.fields?.[
        editingState.editingField.fieldIndex
      ]?._id as string

      elementToScrollTo = document.querySelector(`[data-field-id="${fieldId}"]`)
    } else if (editingState.editingRow) {
      // Scroll to row
      const { rowIndex } = editingState.editingRow
      elementToScrollTo = document.querySelector(`[data-row-index="${rowIndex}"]`)
    }

    if (elementToScrollTo) {
      elementToScrollTo.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest'
      })
    }
  }, [editingState, rows])

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        flex: 1,
        backgroundColor: 'background.default',
        overflow: 'auto'
      }}
    >
      <Box display='flex' flexDirection='column' sx={{ flex: 1, overflow: 'auto', px, py, gap }}>
        {rows.map((row, rowIndex) => {
          const isRowHidden = evaluateCondition(row.hidden, formValues, context)

          if (isRowHidden) {
            return null
          }

          const isRowDisabled = evaluateCondition(row.disabled, formValues, context)

          return (
            <Row
              key={row._id}
              row={row}
              rowIndex={rowIndex}
              disabled={isRowDisabled}
              rowHeight={rowHeight}
            />
          )
        })}
      </Box>
    </Box>
  )
}

export default LayoutRenderer
