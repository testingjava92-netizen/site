import {
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  FormHelperText,
  Box
} from '@mui/material'
import { useFormContext, Controller } from 'react-hook-form'
import { FieldComponentProps, IRadioLayoutField, RadioOrientation } from '../../../types'
import { evaluateCondition, getIconComponent } from '../../../utils/utils'
import { useCardContext } from '../../../hooks/useCardContext'

const LayoutRadio = ({ field, disabled = false }: FieldComponentProps<IRadioLayoutField>) => {
  const { path, label, options, required, orientation = RadioOrientation.VERTICAL } = field
  const { control, watch } = useFormContext()
  const { collection } = useCardContext()
  const formValues = watch()

  return (
    <Controller
      name={path}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <FormControl
          component='fieldset'
          error={!!error}
          required={required ?? false}
          disabled={disabled}
          sx={{
            width: '100%',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          <FormLabel
            component='legend'
            sx={{
              fontSize: '0.875rem',
              fontWeight: 500,
              color: error ? 'error.main' : 'text.primary',
              '&.Mui-focused': {
                color: error ? 'error.main' : 'primary.main'
              }
            }}
          >
            {label}
          </FormLabel>

          <RadioGroup
            {...field}
            value={field.value ?? ''}
            onChange={(event) => field.onChange(event.target.value)}
            row={orientation === RadioOrientation.HORIZONTAL}
            sx={{
              mt: 1,
              ...(orientation === RadioOrientation.HORIZONTAL && {
                gap: 2,
                flexWrap: 'wrap'
              })
            }}
          >
            {options?.values?.map((option) => {
              const IconComponent = option.icon ? getIconComponent(option.icon) : null

              return (
                <FormControlLabel
                  key={`${option.value}`}
                  value={option.value}
                  control={<Radio size='small' />}
                  label={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      {IconComponent && (
                        <IconComponent sx={{ fontSize: 18, color: 'text.secondary' }} />
                      )}
                      {option.label}
                    </Box>
                  }
                  disabled={
                    disabled ||
                    evaluateCondition(option.disabled, formValues, collection.uiSchema.context)
                  }
                  sx={{
                    margin: 0,
                    '& .MuiFormControlLabel-label': {
                      fontSize: '0.875rem'
                    }
                  }}
                />
              )
            })}
          </RadioGroup>

          {error?.message && (
            <FormHelperText sx={{ ml: 0, mt: 0.5 }}>{error.message}</FormHelperText>
          )}
        </FormControl>
      )}
    />
  )
}

export default LayoutRadio
