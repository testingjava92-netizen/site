import { FieldComponentProps, ILayoutField } from '../../types'
import { componentMap } from '../../constants/mappers'
import { Box } from '@mui/material'
import useFieldHighlightStyles from '../../hooks/useFieldHighlightStyles'
import { useCardContext } from '../../hooks/useCardContext'
import { DEFAULT_GAP } from '../../../DNDCardBuilder/constants'

const groupFieldsIntoVisualRows = (fields: ILayoutField[]): ILayoutField[][] => {
  const visualRows: ILayoutField[][] = []
  let currentRow: ILayoutField[] = []
  let currentRowWidth = 0

  for (const field of fields) {
    const fieldWidth = field.width || 12

    if (currentRowWidth + fieldWidth > 12 && currentRow.length > 0) {
      visualRows.push(currentRow)
      currentRow = [field]
      currentRowWidth = fieldWidth
    } else {
      currentRow.push(field)
      currentRowWidth += fieldWidth
    }
  }

  if (currentRow.length > 0) {
    visualRows.push(currentRow)
  }

  return visualRows
}

const getFlexBasis = ({
  width,
  gap,
  fields,
  fieldIndex
}: {
  width: number | undefined
  gap: number
  fields: ILayoutField[]
  fieldIndex: number
}): string => {
  const actualWidth = width || 12
  const percentage = (actualWidth / 12) * 100

  // Group fields into visual rows based on their widths
  const visualRows = groupFieldsIntoVisualRows(fields)

  // Find which visual row contains the current field
  const currentField = fields[fieldIndex]
  let fieldsInSameVisualRow: ILayoutField[] = []

  for (const visualRow of visualRows) {
    if (visualRow.some((f) => f._id === currentField._id)) {
      fieldsInSameVisualRow = visualRow
      break
    }
  }

  // If field takes full width or is alone in its visual row, no gap adjustment needed
  if (actualWidth === 12 || fieldsInSameVisualRow.length === 1) {
    return `${percentage}%`
  }

  // Calculate gaps only between fields that are actually in the same visual row
  const numberOfGaps = fieldsInSameVisualRow.length - 1
  const totalGapInPx = numberOfGaps * gap * 8 // gap is in theme units (8px each)

  // Each field's proportional share of the total gap within its visual row
  const fieldGapShare = (actualWidth / 12) * totalGapInPx

  return `calc(${percentage}% - ${fieldGapShare}px)`
}

export const Field = ({
  field,
  fieldIndex,
  rowIndex,
  rowHeight,
  disabled = false
}: {
  field: ILayoutField
  fieldIndex: number
  rowIndex: number
  rowHeight: string
  disabled?: boolean
}) => {
  const { collection } = useCardContext()
  const row = collection.uiSchema.rows?.[rowIndex ?? -1]
  const fields = row?.fields ?? []
  const gap = row?.gap ?? DEFAULT_GAP

  const Component = componentMap[field.component] as React.ComponentType<
    FieldComponentProps<ILayoutField>
  >

  const highlightStyles = useFieldHighlightStyles({
    fieldId: field._id,
    fieldIndex,
    rowIndex
  })

  return (
    <Box
      data-field-id={field._id}
      sx={{
        minWidth: 0,

        flexShrink: field.width ? 0 : 1,
        flexGrow: field.width ? 0 : 1,
        flexBasis: field.width
          ? getFlexBasis({
              width: field.width,
              gap,
              fields,
              fieldIndex: fields.findIndex((f) => f._id === field._id)
            })
          : '0',

        display: 'flex',
        minHeight: '100%',
        ...highlightStyles
      }}
    >
      <Component field={field} rowHeight={rowHeight} disabled={disabled} />
    </Box>
  )
}
