import z from 'zod'

import { ICardSchemaMeta, ICollection } from '../../types'

export const uiSchema: ICardSchemaMeta = {
  rows: [],
  context: {}
}

export const emptyCard: ICollection = {
  name: 'New Card',
  schema: z.object({}),
  uiSchema
}
