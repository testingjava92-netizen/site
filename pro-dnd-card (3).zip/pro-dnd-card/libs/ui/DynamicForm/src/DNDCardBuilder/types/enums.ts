export enum ViewType {
  Rows = 'rows',
  EditRow = 'editRow',
  EditField = 'editField',
  EditOption = 'editOption',
  EditCondition = 'editCondition'
}

export enum CategoryType {
  Basic = 'basic',
  Layout = 'layout',
  Validation = 'validation',
  Input = 'input',
  Options = 'options',
  Advanced = 'advanced'
}

export enum RowCategoryType {
  Fields = 'fields',
  Settings = 'settings',
  Layout = 'layout',
  Advanced = 'advanced'
}

export enum RowsCategoryType {
  Rows = 'rows',
  Layout = 'layout'
}

export enum OptionCategoryType {
  General = 'general',
  Advanced = 'advanced'
}

export enum ConditionType {
  Single = 'single',
  Multiple = 'multiple'
}
