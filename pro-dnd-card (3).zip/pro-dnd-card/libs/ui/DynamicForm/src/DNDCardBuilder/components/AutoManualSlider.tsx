import React from 'react'
import {
  Box,
  Switch,
  FormControlLabel,
  Slider,
  Typography,
  FormControl,
  FormLabel
} from '@mui/material'
import { DND_CARD_BUILDER_LABELS } from '../constants'

export interface AutoManualSliderProps {
  label: string
  value?: number
  onChange: (value: number | undefined) => void
  min: number
  max: number
  step?: number
  autoLabel?: string
  manualLabel?: string
  valueLabelFormat?: (value: number) => string
  displayFormat?: (value: number) => string
  marks?: boolean
  sliderProps?: React.ComponentProps<typeof Slider>
  initialValue: number
}

const AutoManualSlider: React.FC<AutoManualSliderProps> = ({
  label,
  value,
  onChange,
  min,
  max,
  initialValue,
  valueLabelFormat,
  displayFormat,
  sliderProps = {},
  autoLabel = DND_CARD_BUILDER_LABELS.AUTO_LABEL,
  manualLabel = DND_CARD_BUILDER_LABELS.MANUAL_LABEL
}) => {
  const [isAuto, setIsAuto] = React.useState(value === undefined)
  const [sliderValue, setSliderValue] = React.useState(value || initialValue)

  // Update internal state when value prop changes
  React.useEffect(() => {
    if (value !== undefined) {
      setIsAuto(false)
      setSliderValue(value)
    } else {
      setIsAuto(true)
      setSliderValue(initialValue)
    }
  }, [value, min, initialValue])

  const handleToggle = (isAutoMode: boolean) => {
    setIsAuto(isAutoMode)
    if (isAutoMode) {
      onChange(undefined)
    } else {
      onChange(sliderValue)
    }
  }

  const handleSliderChange = (_: Event, newValue: number | number[]) => {
    const numValue = Array.isArray(newValue) ? newValue[0] : newValue
    setSliderValue(numValue)
    if (!isAuto) {
      onChange(numValue)
    }
  }

  return (
    <FormControl fullWidth sx={{ mb: 0 }}>
      <FormLabel component='legend'>
        <Typography variant='subtitle2' sx={{ mb: 1 }}>
          {label}
        </Typography>
      </FormLabel>

      <FormControlLabel
        control={
          <Switch
            checked={!isAuto}
            onChange={(e) => handleToggle(!e.target.checked)}
            size='small'
          />
        }
        label={isAuto ? autoLabel : manualLabel}
        sx={{ mb: 1 }}
      />

      {!isAuto && (
        <>
          <Box sx={{ px: 2 }}>
            <Slider
              value={sliderValue}
              onChange={handleSliderChange}
              min={min}
              max={max}
              step={1}
              marks
              valueLabelDisplay='auto'
              valueLabelFormat={valueLabelFormat}
              {...sliderProps}
            />
          </Box>
          {displayFormat && (
            <Typography variant='body2' color='text.secondary' sx={{ textAlign: 'center', mt: 1 }}>
              {displayFormat(sliderValue)}
            </Typography>
          )}
        </>
      )}
    </FormControl>
  )
}

export default AutoManualSlider
