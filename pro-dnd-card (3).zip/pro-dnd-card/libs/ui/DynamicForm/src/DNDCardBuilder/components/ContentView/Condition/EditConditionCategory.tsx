import React, { useMemo } from 'react'
import { Box, FormControlLabel, Radio, RadioGroup, TextField } from '@mui/material'
import { ConditionType } from '../../../types'
import {
  DEFAULT_MULTIPLE_CONDITION,
  DEFAULT_SINGLE_CONDITION,
  DND_CARD_BUILDER_LABELS
} from '../../../constants'
import { ConditionGroup, SingleCondition } from '../../../../DynamicForm/types'
import SingleConditionEditor from './Categories/SingleConditionEditor/SingleConditionEditor'
import MultipleConditionsCategory from './Categories/MultipleConditionsCategory'

const EditConditionCategory: React.FC<{
  condition: ConditionGroup | SingleCondition
  onChange: (condition: ConditionGroup | SingleCondition) => void
}> = ({ condition, onChange }) => {
  const conditionType = useMemo<ConditionType>(() => {
    const isMultipleCondition = condition && 'conditions' in condition

    if (isMultipleCondition) {
      return ConditionType.Multiple
    }
    return ConditionType.Single
  }, [condition])

  const handleCategoryChange = (category: ConditionType) => {
    const currentTitle = condition?.title
    if (category === ConditionType.Single) {
      onChange({ ...DEFAULT_SINGLE_CONDITION, title: currentTitle })
    } else {
      onChange({ ...DEFAULT_MULTIPLE_CONDITION, title: currentTitle })
    }
  }

  const handleTitleChange = (title: string) => {
    onChange({
      ...condition,
      title: title || undefined
    })
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4, p: 4, flex: 1, overflow: 'auto' }}>
      {/* Title and condition type on the same row */}
      <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
        <TextField
          label='כותרת התנאי'
          value={condition?.title || ''}
          onChange={(e) => handleTitleChange(e.target.value)}
          placeholder='הכנס כותרת אופציונלית לתנאי'
          helperText='כותרת אופציונלית לזיהוי התנאי'
          sx={{
            flex: 1,
            '& .MuiOutlinedInput-root': {
              bgcolor: 'background.default'
            }
          }}
        />

        <Box sx={{ pt: 1 }}>
          <RadioGroup
            value={conditionType}
            onChange={(e) => handleCategoryChange(e.target.value as ConditionType)}
            row
          >
            <FormControlLabel
              value={ConditionType.Single}
              control={<Radio />}
              label={DND_CARD_BUILDER_LABELS.SINGLE_CONDITION}
              sx={{ '& .MuiFormControlLabel-label': { fontSize: '0.875rem' } }}
            />

            <FormControlLabel
              value={ConditionType.Multiple}
              control={<Radio />}
              label={DND_CARD_BUILDER_LABELS.MULTIPLE_CONDITIONS}
              sx={{ '& .MuiFormControlLabel-label': { fontSize: '0.875rem' } }}
            />
          </RadioGroup>
        </Box>
      </Box>

      {conditionType === ConditionType.Single && (
        <SingleConditionEditor
          condition={condition as SingleCondition}
          onChange={(newCondition) => {
            onChange(newCondition)
          }}
        />
      )}

      {conditionType === ConditionType.Multiple && (
        <MultipleConditionsCategory
          condition={condition as ConditionGroup}
          onChange={(newCondition) => {
            onChange(newCondition)
          }}
        />
      )}
    </Box>
  )
}

export default EditConditionCategory
