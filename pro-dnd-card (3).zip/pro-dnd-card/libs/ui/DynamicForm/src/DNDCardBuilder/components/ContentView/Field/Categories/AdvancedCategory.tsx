import React from 'react'
import { Divider, Stack } from '@mui/material'
import { ConditionField, ConditionGroup } from '../../../../../DynamicForm/types'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../../constants'
import BooleanOrConditionsManager from '../../Condition/BooleanOrConditionsManager'

interface AdvancedCategoryProps {
  rowIndex: number
  fieldIndex: number
}

const AdvancedCategory: React.FC<AdvancedCategoryProps> = ({ rowIndex, fieldIndex }) => {
  const { fieldPathOptions, setSelectedCollection, selectedCollection, navigateToEditCondition } =
    useDNDCardBuilderContext()

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[fieldIndex]

  const updateField = (updates: Record<string, unknown>) => {
    if (!field) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((row, index) =>
          index === rowIndex
            ? {
                ...row,
                fields: row.fields?.map((fieldItem) =>
                  fieldItem._id === field._id ? { ...fieldItem, ...updates } : fieldItem
                )
              }
            : row
        )
      }
    }))
  }

  if (!field) {
    return null
  }

  return (
    <Stack spacing={3}>
      <BooleanOrConditionsManager
        label={DND_CARD_BUILDER_LABELS.FIELD_HIDDEN}
        value={(field as { hidden?: boolean | ConditionGroup }).hidden}
        onChange={(value) => updateField({ hidden: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              fieldIndex,
              conditionField: ConditionField.hidden
            })
          }
        }}
      />

      <Divider />

      <BooleanOrConditionsManager
        label={DND_CARD_BUILDER_LABELS.FIELD_DISABLED}
        value={(field as { disabled?: boolean | ConditionGroup }).disabled}
        onChange={(value) => updateField({ disabled: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              fieldIndex,
              conditionField: ConditionField.disabled
            })
          }
        }}
      />
    </Stack>
  )
}

export default AdvancedCategory
