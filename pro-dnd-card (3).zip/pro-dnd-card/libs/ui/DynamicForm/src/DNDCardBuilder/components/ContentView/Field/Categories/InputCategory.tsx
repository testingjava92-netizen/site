import React from 'react'
import { TextField, Stack, Typography, Switch, FormControlLabel } from '@mui/material'
import {
  FieldComponentType,
  IInputDateRangeLayoutField,
  IInputLayoutField,
  IInputNumberLayoutField,
  IInputTextLayoutField,
  IInputSliderLayoutField
} from '../../../../../DynamicForm/types'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../../constants'

interface InputCategoryProps {
  rowIndex: number
  fieldIndex: number
}

const InputCategory: React.FC<InputCategoryProps> = ({ rowIndex, fieldIndex }) => {
  const { setSelectedCollection, selectedCollection } = useDNDCardBuilderContext()

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[fieldIndex]

  const updateField = (updates: Record<string, unknown>) => {
    if (!field) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((row, index) =>
          index === rowIndex
            ? {
                ...row,
                fields: row.fields?.map((fieldItem) =>
                  fieldItem._id === field._id ? { ...fieldItem, ...updates } : fieldItem
                )
              }
            : row
        )
      }
    }))
  }

  if (!field) {
    return null
  }

  const isDateRange = field.component === FieldComponentType.inputDateRange
  const dateRangeField = field as IInputDateRangeLayoutField

  if (isDateRange) {
    return (
      <Stack spacing={3}>
        <Typography variant='h6' sx={{ mb: 2 }}>
          הגדרות שדה טווח תאריכים
        </Typography>

        <TextField
          label='תווית תאריך התחלה'
          value={dateRangeField.startDateLabel ?? ''}
          onChange={(e) => updateField({ startDateLabel: e.target.value })}
          fullWidth
        />

        <TextField
          label='placeholder תאריך התחלה'
          value={dateRangeField.startDatePlaceholder ?? ''}
          onChange={(e) => updateField({ startDatePlaceholder: e.target.value })}
          fullWidth
        />

        <TextField
          label='תווית תאריך הסיום'
          value={dateRangeField.endDateLabel ?? ''}
          onChange={(e) => updateField({ endDateLabel: e.target.value })}
          fullWidth
        />

        <TextField
          label='placeholder תאריך סיום'
          value={dateRangeField.endDatePlaceholder ?? ''}
          onChange={(e) => updateField({ endDatePlaceholder: e.target.value })}
          fullWidth
        />
      </Stack>
    )
  }

  const inputField = field as IInputLayoutField
  const isNumberInput = inputField.component === FieldComponentType.inputNumber
  const isSliderInput = inputField.component === FieldComponentType.inputSlider
  const numberField = isNumberInput ? (inputField as IInputNumberLayoutField) : null
  const sliderField = isSliderInput ? (inputField as IInputSliderLayoutField) : null
  const textField = !isNumberInput && !isSliderInput ? (inputField as IInputTextLayoutField) : null

  return (
    <Stack spacing={3}>
      {/* Show placeholder only for fields that support it (not slider) */}
      {!isSliderInput && (
        <TextField
          label={DND_CARD_BUILDER_LABELS.PLACEHOLDER}
          value={(field as { placeholder?: string }).placeholder ?? ''}
          onChange={(e) => updateField({ placeholder: e.target.value })}
          fullWidth
        />
      )}

      {/* Number input specific fields */}
      {isNumberInput && numberField && (
        <>
          <TextField
            label='ערך מינימלי'
            type='number'
            value={numberField.min ?? ''}
            onChange={(e) =>
              updateField({ min: e.target.value ? Number(e.target.value) : undefined })
            }
            fullWidth
            helperText='הערך המינימלי המותר לשדה מספר'
          />

          <TextField
            label='ערך מקסימלי'
            type='number'
            value={numberField.max ?? ''}
            onChange={(e) =>
              updateField({ max: e.target.value ? Number(e.target.value) : undefined })
            }
            fullWidth
            helperText='הערך המקסימלי המותר לשדה מספר'
          />
        </>
      )}

      {/* Slider input specific fields */}
      {isSliderInput && sliderField && (
        <>
          <TextField
            label='ערך מינימלי'
            type='number'
            value={sliderField.min ?? 0}
            onChange={(e) => updateField({ min: e.target.value ? Number(e.target.value) : 0 })}
            fullWidth
            helperText='הערך המינימלי עבור הסליידר (ברירת מחדל: 0)'
          />

          <TextField
            label='ערך מקסימלי'
            type='number'
            value={sliderField.max ?? 100}
            onChange={(e) => updateField({ max: e.target.value ? Number(e.target.value) : 100 })}
            fullWidth
            helperText='הערך המקסימלי עבור הסליידר (ברירת מחדל: 100)'
          />

          <TextField
            label='צעד'
            type='number'
            value={sliderField.step ?? 1}
            onChange={(e) => updateField({ step: e.target.value ? Number(e.target.value) : 1 })}
            slotProps={{
              htmlInput: {
                min: 0.1
              }
            }}
            fullWidth
            helperText='גודל הצעד עבור הסליידר (ברירת מחדל: 1)'
          />

          <FormControlLabel
            control={
              <Switch
                checked={sliderField.showValue ?? true}
                onChange={(e) => updateField({ showValue: e.target.checked })}
              />
            }
            label='הצג ערך נוכחי'
            sx={{ alignItems: 'flex-start' }}
          />

          <FormControlLabel
            control={
              <Switch
                checked={sliderField.showMarks ?? false}
                onChange={(e) => updateField({ showMarks: e.target.checked })}
              />
            }
            label='הצג סימני צעדים'
            sx={{ alignItems: 'flex-start' }}
          />
        </>
      )}

      {/* Text input specific fields */}
      {textField && (
        <>
          <TextField
            label='מקסימום תווים'
            type='number'
            value={textField.maxLength ?? ''}
            onChange={(e) =>
              updateField({ maxLength: e.target.value ? Number(e.target.value) : undefined })
            }
            slotProps={{
              htmlInput: {
                min: 1
              }
            }}
            fullWidth
            helperText='מגביל את מספר התווים שניתן להקליד'
          />

          <FormControlLabel
            control={
              <Switch
                checked={textField.showCharacterCounter ?? false}
                onChange={(e) => updateField({ showCharacterCounter: e.target.checked })}
              />
            }
            label='הצג מונה תווים'
            sx={{ alignItems: 'flex-start' }}
          />
        </>
      )}

      <TextField
        label='תיאור'
        value={(field as { description?: string }).description ?? ''}
        onChange={(e) => updateField({ description: e.target.value })}
        multiline
        rows={3}
        fullWidth
      />
    </Stack>
  )
}

export default InputCategory
