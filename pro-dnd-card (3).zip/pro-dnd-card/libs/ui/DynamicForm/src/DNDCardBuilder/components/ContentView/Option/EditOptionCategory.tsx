import React from 'react'
import { Box } from '@mui/material'
import GeneralOptionCategory from './Categories/GeneralOptionCategory'
import AdvancedOptionCategory from './Categories/AdvancedOptionCategory'
import { OptionCategoryType } from '../../../types'

interface EditOptionCategoryProps {
  selectedCategory: string
  rowIndex: number
  fieldIndex: number
  optionIndex: number
}

const EditOptionCategory: React.FC<EditOptionCategoryProps> = ({
  selectedCategory,
  rowIndex,
  fieldIndex,
  optionIndex
}) => {
  return (
    <Box
      sx={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        p: 4
      }}
    >
      {selectedCategory === OptionCategoryType.General && (
        <GeneralOptionCategory
          rowIndex={rowIndex}
          fieldIndex={fieldIndex}
          optionIndex={optionIndex}
        />
      )}
      {selectedCategory === OptionCategoryType.Advanced && (
        <AdvancedOptionCategory
          rowIndex={rowIndex}
          fieldIndex={fieldIndex}
          optionIndex={optionIndex}
        />
      )}
    </Box>
  )
}

export default EditOptionCategory
