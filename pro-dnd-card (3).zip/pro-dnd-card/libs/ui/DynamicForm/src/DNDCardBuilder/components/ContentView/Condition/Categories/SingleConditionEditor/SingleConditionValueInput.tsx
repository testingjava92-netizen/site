import { Box, FormControlLabel, Switch, TextField } from '@mui/material'
import { ConditionValue, DefaultSchema, SingleCondition } from '../../../../../../DynamicForm/types'

type ValueType = 'string' | 'number' | 'boolean'

interface SingleConditionValueInputProps<Schema = DefaultSchema> {
  condition: SingleCondition<Schema>
  valueType: ValueType
  canChooseValueType: boolean
  needsValueInput: boolean
  onValueTypeChange: (newType: ValueType) => void
  onValueChange: (value: ConditionValue) => void
}

const SingleConditionValueInput = <Schema extends DefaultSchema = DefaultSchema>({
  condition,
  valueType,
  canChooseValueType: _canChooseValueType,
  needsValueInput,
  onValueTypeChange: _onValueTypeChange,
  onValueChange
}: SingleConditionValueInputProps<Schema>) => {
  if (!needsValueInput) {
    return null
  }

  const renderInput = () => {
    switch (valueType) {
      case 'boolean':
        return (
          <FormControlLabel
            control={
              <Switch
                checked={Boolean(condition.value)}
                onChange={(e) => onValueChange(e.target.checked)}
              />
            }
            label={condition.value ? 'אמת' : 'שקר'}
          />
        )
      case 'number':
        return (
          <TextField
            label='ערך מספרי'
            value={condition.value ?? ''}
            onChange={(e) => {
              const value = e.target.value
              if (value === '') {
                onValueChange('')
              } else {
                const numericValue = Number(value)
                if (!isNaN(numericValue)) {
                  onValueChange(numericValue)
                } else {
                  // Keep the string value for partial input (e.g., "3.", "-", etc.)
                  onValueChange(value)
                }
              }
            }}
            onBlur={(e) => {
              // On blur, ensure we have a valid number or empty string
              const value = e.target.value
              if (value === '') {
                onValueChange('')
              } else {
                const numericValue = parseFloat(value)
                onValueChange(isNaN(numericValue) ? 0 : numericValue)
              }
            }}
            type='number'
            fullWidth
            placeholder='הכנס מספר'
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'background.default'
              }
            }}
          />
        )
      case 'string':
      default:
        return (
          <TextField
            label='ערך טקסט'
            value={condition.value ?? ''}
            onChange={(e) => onValueChange(e.target.value)}
            type='text'
            fullWidth
            placeholder='הכנס ערך'
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'background.default'
              }
            }}
          />
        )
    }
  }

  return <Box>{renderInput()}</Box>
}

export default SingleConditionValueInput
