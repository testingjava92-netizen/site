import React from 'react'
import { Stack, Typography, FormControl, InputLabel, Select, MenuItem } from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DEFAULT_SINGLE_CONDITION, DND_CARD_BUILDER_LABELS } from '../../../../constants'
import { ConditionGroup, LogicalOperator } from '../../../../../DynamicForm/types'
import ItemsList from '../../ItemsList/ItemsList'

interface MultipleConditionsCategoryProps {
  condition: ConditionGroup
  onChange: (condition: ConditionGroup) => void
}

const MultipleConditionsCategory: React.FC<MultipleConditionsCategoryProps> = ({
  condition,
  onChange
}) => {
  const { navigateToEditCondition, editingCondition } = useDNDCardBuilderContext()

  const conditionGroup = condition

  const handleOperatorChange = (operator: LogicalOperator) => {
    onChange({
      ...conditionGroup,
      operator
    })
  }

  const handleAddCondition = (index?: number) => {
    onChange({
      ...conditionGroup,
      conditions: [
        ...conditionGroup.conditions.slice(0, index ?? conditionGroup.conditions.length),
        DEFAULT_SINGLE_CONDITION,
        ...conditionGroup.conditions.slice(index ?? conditionGroup.conditions.length)
      ]
    })
  }

  const handleDeleteCondition = (index: number) => {
    onChange({
      ...conditionGroup,
      conditions: conditionGroup.conditions.filter((_, i) => i !== index)
    })
  }

  const handleEditCondition = (index: number) => {
    if (editingCondition) {
      navigateToEditCondition({
        ...editingCondition,
        conditionIndexes: [...(editingCondition.conditionIndexes ?? []), index]
      })
    }
  }

  return (
    <Stack spacing={3}>
      {/* Logical operator selector */}
      <FormControl sx={{ minWidth: 150 }}>
        <InputLabel>אופרטור לוגי</InputLabel>
        <Select
          value={conditionGroup.operator || LogicalOperator.AND}
          label='אופרטור לוגי'
          onChange={(e) => handleOperatorChange(e.target.value as LogicalOperator)}
          sx={{
            '& .MuiOutlinedInput-root': {
              bgcolor: 'background.default'
            }
          }}
        >
          <MenuItem value={LogicalOperator.AND}>AND (וגם)</MenuItem>
          <MenuItem value={LogicalOperator.OR}>OR (או)</MenuItem>
        </Select>
      </FormControl>

      <Stack spacing={2}>
        <Typography variant='body2' fontWeight={500}>
          תנאים ({conditionGroup.conditions.length})
        </Typography>

        <ItemsList
          items={conditionGroup.conditions.map((_, index) => index.toString()) ?? []}
          onAddItem={handleAddCondition}
          deleteItemLabel={DND_CARD_BUILDER_LABELS.DELETE_CONDITION}
          addItemLabel={DND_CARD_BUILDER_LABELS.ADD_CONDITION}
          onDeleteItem={(itemIndex) => handleDeleteCondition(itemIndex)}
          onEditItem={(itemIndex) => handleEditCondition(itemIndex)}
          renderLabel={(itemIndex) => {
            const condition = conditionGroup.conditions[itemIndex]
            const defaultLabel = `תנאי ${itemIndex + 1}`
            return condition?.title ? `${defaultLabel}: ${condition.title}` : defaultLabel
          }}
          emptyListMessage='אין תנאים בקבוצה זו'
        />
      </Stack>
    </Stack>
  )
}

export default MultipleConditionsCategory
