import DNDCardBuilderProvider from './DNDCardBuilderProvider'
import Header from './Header'
import BreadcrumbsBar from './BreadcrumbsBar'
import ContentView from './ContentView/ContentView'
import { Box, Skeleton } from '@mui/material'
import { DNDCardBuilderProps } from '../types'

const DNDCardBuilder = (props: DNDCardBuilderProps) => {
  return props.selectedCollection ? (
    <DNDCardBuilderProvider
      editingState={props.editingState}
      setEditingState={props.setEditingState}
      selectedCollection={props.selectedCollection}
      setSelectedCollection={props.setSelectedCollection}
    >
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: 'background.default',
          overflow: 'hidden',
          flex: 1
        }}
      >
        <Header />

        <BreadcrumbsBar />

        <ContentView />
      </Box>
    </DNDCardBuilderProvider>
  ) : (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'background.default',
        overflow: 'hidden',
        flex: 1
      }}
    >
      <Skeleton variant='rectangular' height='100%' width='100%' />
    </Box>
  )
}

export default DNDCardBuilder
