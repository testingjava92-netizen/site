import { Box } from '@mui/material'
import DynamicForm from '@pro3/DynamicForm'
import { useContext } from 'react'
import CollectionsWrapper from '../CollectionsWrapper/CollectionsWrapper'
import CollectionsProvider from '../CollectionsWrapper/CollectionsProvider'
import { CollectionsContext } from '../CollectionsWrapper/CollectionsContext'

const DynamicFormViewContent = () => {
  const { selectedCollection } = useContext(CollectionsContext)

  return (
    <Box
      p={3}
      sx={{
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
        alignItems: 'center',
        overflow: 'hidden',
        height: '100%'
      }}
    >
      <DynamicForm key={selectedCollection?.name ?? ''} collection={selectedCollection} />
    </Box>
  )
}

const DynamicFormView = () => {
  return (
    <CollectionsProvider>
      <CollectionsWrapper title='כרטיס'>
        <DynamicFormViewContent />
      </CollectionsWrapper>
    </CollectionsProvider>
  )
}

export default DynamicFormView
