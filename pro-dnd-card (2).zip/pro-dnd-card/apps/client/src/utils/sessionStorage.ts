/**
 * Utility functions for managing session storage
 */

import { ICollection } from '@pro3/DynamicForm'

/**
 * Collection data without the schema (for storage purposes)
 * The schema contains Zod objects that can't be serialized to JSON
 */
export type StoredCollection = Omit<ICollection, 'schema'>

/**
 * Get an item from session storage and parse it as JSON
 * @param key - The session storage key
 * @returns The parsed value or null if not found or invalid JSON
 */
export const getFromSessionStorage = <T>(key: string): T | null => {
  try {
    const item = sessionStorage.getItem(key)
    if (!item) return null

    const parsed = JSON.parse(item)
    return parsed
  } catch (error) {
    console.warn(`Failed to get item from session storage with key "${key}":`, error)
    return null
  }
}

/**
 * Set an item in session storage as JSON
 * @param key - The session storage key
 * @param value - The value to store
 */
export const setInSessionStorage = <T>(key: string, value: T): void => {
  try {
    sessionStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.warn(`Failed to set item in session storage with key "${key}":`, error)
  }
}

/**
 * Set a collection in session storage, excluding the schema
 * @param collection - The collection to store (schema will be excluded)
 */
export const setCollectionInSessionStorage = (collection: ICollection | null): void => {
  if (!collection) {
    setInSessionStorage(SESSION_STORAGE_KEYS.SELECTED_COLLECTION, null)
    return
  }

  // Exclude the schema property when saving to storage
  const storedCollection: StoredCollection = {
    name: collection.name,
    uiSchema: collection.uiSchema
  }

  setInSessionStorage(SESSION_STORAGE_KEYS.SELECTED_COLLECTION, storedCollection)
}

/**
 * Get a stored collection from session storage
 * @returns The stored collection data (without schema) or null
 */
export const getStoredCollectionFromSessionStorage = (): StoredCollection | null => {
  return getFromSessionStorage<StoredCollection>(SESSION_STORAGE_KEYS.SELECTED_COLLECTION)
}

/**
 * Remove an item from session storage
 * @param key - The session storage key
 */
export const removeFromSessionStorage = (key: string): void => {
  try {
    sessionStorage.removeItem(key)
  } catch (error) {
    console.warn(`Failed to remove item from session storage with key "${key}":`, error)
  }
}

// Session storage keys
export const SESSION_STORAGE_KEYS = {
  SELECTED_COLLECTION: 'selectedCollection',
  DEFAULT_VALUES: 'defaultValues',
  EDITING_STATE: 'editingState'
} as const

/**
 * Clear all app-related session storage items (useful for debugging)
 */
export const clearAppSessionStorage = (): void => {
  try {
    Object.values(SESSION_STORAGE_KEYS).forEach((key) => {
      sessionStorage.removeItem(key)
    })
    console.log('Cleared all app session storage items')
  } catch (error) {
    console.warn('Failed to clear app session storage:', error)
  }
}
