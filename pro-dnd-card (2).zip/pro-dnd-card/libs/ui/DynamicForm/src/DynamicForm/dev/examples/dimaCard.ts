import z from 'zod'
import { v4 as uuidv4 } from 'uuid'
import {
  FieldComponentType,
  ICardSchemaMeta,
  IconType,
  IOption,
  LazyLoaderType,
  WidthKey,
  ConditionOperator,
  RadioOrientation
} from '../../types'
import { ICollection } from '../../types'

enum Disney {
  DISNEY = 'disney',
  PIXAR = 'pixar',
  MARVEL = 'marvel',
  STARWARS = 'starwars',
  NINTENDO = 'nintendo'
}

export const dimaCardSchema = ({ loadPirates }: { loadPirates: () => Promise<IOption[]> }) => {
  return z.object({
    name: z.string().min(1, 'יש להזין שם').default(''),

    email: z
      .email('יש להזין אימייל תקין')
      .min(1, 'יש להזין אימייל')
      .max(10, 'אימייל חייב להיות עד 10 תווים')
      .default(''),

    disney: z.enum(Object.values(Disney)).default(Disney.DISNEY),

    // Favorite color radio selection
    favoriteColor: z.enum(['red', 'blue', 'green', 'yellow']).default('blue'),

    // Transportation preference (horizontal layout)
    transportPreference: z.enum(['walk', 'bike', 'car', 'bus']).default('walk'),

    // Meeting datetime
    meetingDateTime: z.date().optional(),

    // Black or White boolean field
    blackOrWhite: z.boolean().default(false),

    priority: z
      .object({
        customer: z
          .number()
          .min(1, 'עדיפות לקוח חייבת להיות מוגדרת')
          .max(10, 'עדיפות לקוח חייבת להיות בין 1 ל-10')
          .default(0),
        employee: z.number().default(0),
        manager: z.number().default(0)
      })
      .default({
        customer: 0,
        employee: 0,
        manager: 0
      }),

    pirate: z
      .object({
        spiritId: z.string().min(1, 'יש להזין פיראט מהרשימה').default('')
      })
      .default({
        spiritId: ''
      })
      .superRefine(async (data, ctx) => {
        const pirates = await loadPirates()
        const pirateEnum = z.enum(pirates.map((d) => d.value) as [string, ...string[]])

        if (data?.spiritId && !pirateEnum.safeParse(data?.spiritId).success) {
          ctx.addIssue({
            code: 'custom',
            message: 'יש להזין פיראט מהרשימה',
            path: ['pirate', 'spiritId']
          })
        }
      }),

    transportation: z.enum(['car', 'bicycle', 'legs']).default('legs'),
    // Car-only fields
    time: z.number().default(60),
    speed: z.number().default(80),
    through: z.string().default('highway'),

    // Date range field
    dateRange: z
      .object({
        startDate: z.date().nullable().default(null),
        endDate: z.date().nullable().default(null)
      })
      .default({ startDate: null, endDate: null })
      .superRefine((val, ctx) => {
        if (val.startDate && val.endDate && val.endDate < val.startDate) {
          ctx.addIssue({
            code: 'custom',
            message: 'תאריך הסיום חייב להיות אחרי תאריך ההתחלה',
            path: ['endDate']
          })
        }
      }),

    // Volume slider field
    volume: z.number().min(0).max(100).default(50),

    // Advanced settings
    subscribed: z.boolean().default(false),
    newsletterTopics: z
      .array(z.enum(['tech', 'design', 'business', 'science', 'education']))
      .default([]),
    darkModeEnabled: z.boolean().default(false)
  })
}

export type IDimaCardSchema = z.infer<ReturnType<typeof dimaCardSchema>>

export const uiSchema: ICardSchemaMeta<IDimaCardSchema> = {
  rows: [
    {
      _id: uuidv4(),
      fields: [
        {
          _id: uuidv4(),
          label: 'דיסני',
          path: 'disney',
          component: FieldComponentType.buttonsGroup,
          options: {
            values: [
              { value: 'disney', label: 'דיסני', badge: { text: 'חדש', color: 'info' } },
              { value: 'pixar', label: 'פיקסר' },
              { value: 'marvel', label: 'מרבל' },
              {
                value: 'starwars',
                label: 'סטארוורס',
                badge: { text: 'לא בשימוש', color: 'warning' }
              },
              { value: 'nintendo', label: 'ניטנדו' }
            ]
          },
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'disney',
          label: 'שדה חדש',
          component: FieldComponentType.select,
          placeholder: 'הכנס טקסט כמקום מחזיק...',
          width: WidthKey.W12,
          options: {
            values: [
              {
                value: 'option_1',
                label: 'Option 1'
              },
              {
                value: 'option_2',
                label: 'Option 2'
              },
              {
                value: 'option_3',
                label: 'Option 3'
              }
            ]
          }
        }
      ]
    },

    {
      _id: uuidv4(),
      fields: [
        {
          _id: uuidv4(),
          path: 'name',
          label: 'שם',
          component: FieldComponentType.inputText,
          placeholder: 'הכנס את השם',
          width: WidthKey.W6,
          required: true
        },

        {
          _id: uuidv4(),
          path: 'priority.customer',
          label: 'תעדוף',
          required: true,
          component: FieldComponentType.inputNumber,
          placeholder: '',
          min: 1,
          max: 10,
          width: WidthKey.W6
        },
        {
          _id: uuidv4(),
          path: 'email',
          label: 'אימייל',
          component: FieldComponentType.inputEmail,
          placeholder: 'הכנס את האימייל',
          required: true,
          maxLength: 10,
          showCharacterCounter: true,
          width: WidthKey.W12
        }
      ]
    },

    {
      _id: uuidv4(),
      fields: [
        {
          _id: uuidv4(),
          path: 'pirate.spiritId',
          label: 'פיראט',
          component: FieldComponentType.select,
          placeholder: 'יש לבחור פיראט',
          required: true,
          options: {
            lazyValues: LazyLoaderType.LOAD_PIRATES
          }
        },
        {
          _id: uuidv4(),
          path: 'transportation',
          component: FieldComponentType.buttonsGroup,
          options: {
            values: [
              { value: 'legs', label: 'רגלים', icon: IconType.LEGS, isIconOnly: true },
              { value: 'bicycle', label: 'אופניים', icon: IconType.BICYCLE, isIconOnly: true },
              { value: 'car', label: 'מכונית', icon: IconType.CAR, isIconOnly: true }
            ]
          }
        }
      ]
    },
    {
      _id: uuidv4(),
      hidden: {
        conditions: [
          { field: 'transportation', operator: ConditionOperator.NOT_EQUALS, value: 'car' }
        ]
      },
      fields: [
        {
          _id: uuidv4(),
          path: 'time',
          label: 'זמן',
          component: FieldComponentType.inputNumber,
          placeholder: '',
          width: WidthKey.W4
        },
        {
          _id: uuidv4(),
          path: 'speed',
          label: 'מהירות',
          component: FieldComponentType.inputNumber,
          placeholder: '',
          width: WidthKey.W4
        },
        {
          _id: uuidv4(),
          path: 'through',
          label: 'דרך',
          component: FieldComponentType.inputText,
          placeholder: '',
          width: WidthKey.W4
        }
      ]
    },
    {
      _id: uuidv4(),
      fields: [
        {
          _id: uuidv4(),
          path: 'volume',
          label: 'עוצמת קול',
          component: FieldComponentType.inputSlider,
          min: 0,
          max: 100,
          step: 5,
          showValue: true,
          showMarks: false,
          width: WidthKey.W12
        }
      ]
    },
    {
      _id: uuidv4(),
      collapsible: true,
      defaultExpanded: false,
      title: 'תאריכים',
      fields: [
        {
          _id: uuidv4(),
          path: 'dateRange',
          component: FieldComponentType.inputDateRange,
          startDateLabel: 'תאריך התחלה',
          endDateLabel: 'תאריך סיום',
          startDatePlaceholder: 'בחר תאריך התחלה',
          endDatePlaceholder: 'בחר תאריך סיום',
          startDatePath: 'startDate',
          endDatePath: 'endDate',
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'meetingDateTime',
          label: 'תאריך ושעת פגישה',
          component: FieldComponentType.inputDateTime,
          placeholder: 'בחר תאריך ושעה',
          width: WidthKey.W6
        },
        {
          _id: uuidv4(),
          path: 'meetingDateTime',
          label: 'תאריך ושעת פגישה',
          component: FieldComponentType.inputDateTime,
          placeholder: 'בחר תאריך ושעה',
          width: WidthKey.W12
        }
      ]
    },

    {
      _id: uuidv4(),
      title: 'הגדרות מתקדמות',
      collapsible: true,
      defaultExpanded: false,
      fields: [
        {
          _id: uuidv4(),
          path: 'blackOrWhite',
          component: FieldComponentType.buttonsGroup,
          options: {
            values: [
              { value: false, label: 'שחור' },
              { value: true, label: 'לבן' }
            ]
          },
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'subscribed',
          label: 'מנוי לניוזלטר',
          component: FieldComponentType.inputCheckbox,
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'newsletterTopics',
          label: 'נושאי ניוזלטר (בחירה מרובה)',
          component: FieldComponentType.chipsSelect,
          multiple: true,
          width: WidthKey.W12,
          options: {
            values: [
              { value: 'tech', label: 'טכנולוגיה' },
              { value: 'design', label: 'עיצוב' },
              { value: 'business', label: 'עסקים' },
              { value: 'science', label: 'מדע' },
              { value: 'education', label: 'חינוך' }
            ]
          },
          hidden: {
            conditions: [
              {
                field: 'subscribed',
                operator: ConditionOperator.IS_FALSE
              }
            ]
          }
        },
        {
          _id: uuidv4(),
          path: 'darkModeEnabled',
          label: 'מצב לילה',
          component: FieldComponentType.inputSwitch,
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'favoriteColor',
          label: 'צבע מועדף',
          component: FieldComponentType.inputRadio,
          required: true,
          options: {
            values: [
              { value: 'red', label: 'אדום' },
              { value: 'blue', label: 'כחול' },
              { value: 'green', label: 'ירוק' },
              { value: 'yellow', label: 'צהוב' }
            ]
          },
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'transportPreference',
          label: 'אמצעי תחבורה מועדף (אופקי)',
          component: FieldComponentType.inputRadio,
          orientation: RadioOrientation.HORIZONTAL,
          required: true,
          options: {
            values: [
              { value: 'walk', label: 'הליכה' },
              { value: 'bike', label: 'אופניים' },
              { value: 'car', label: 'מכונית' }
            ]
          },
          width: WidthKey.W12
        },
        {
          _id: uuidv4(),
          path: 'name',
          label: 'שם',
          component: FieldComponentType.inputText,
          placeholder: 'הכנס את השם',
          width: WidthKey.W6,
          required: true
        },

        {
          _id: uuidv4(),
          path: 'priority.customer',
          label: 'תעדוף',
          required: true,
          component: FieldComponentType.inputNumber,
          placeholder: '',
          min: 1,
          max: 10,
          width: WidthKey.W6
        },
        {
          _id: uuidv4(),
          path: 'email',
          label: 'אימייל',
          component: FieldComponentType.inputEmail,
          placeholder: 'הכנס את האימייל',
          required: true,
          maxLength: 10,
          showCharacterCounter: true,
          width: WidthKey.W12
        }
      ]
    }
  ],
  context: {
    user: {
      role: 'student',
      level: 'beginner'
    },
    preferences: {
      theme: 'dark'
    }
  }
}

export const dimaCard = async ({
  loadPirates
}: {
  loadPirates: () => Promise<IOption[]>
}): Promise<ICollection<IDimaCardSchema>> => {
  return {
    name: 'Dima Card',
    schema: dimaCardSchema({ loadPirates }),
    uiSchema
  }
}
