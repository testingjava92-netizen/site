import { useMemo } from 'react'
import { getHighlightStyles } from '../utils/utils'
import { IOption, ISelectLayoutField } from '../types'
import { useCardContext } from './useCardContext'
import { useTheme } from '@mui/material'

const useOptionHighlightStyles = ({ option }: { option: IOption }) => {
  const { editingState, collection } = useCardContext()
  const theme = useTheme()

  const { isHighlighted, isHovered } = useMemo(() => {
    const isHovered = !!option.value && editingState?.hoveredItem?._id === option.value

    const editingField = collection.uiSchema.rows?.[editingState?.editingOption?.rowIndex ?? -1]
      ?.fields?.[editingState?.editingOption?.fieldIndex ?? -1] as ISelectLayoutField

    const editingOption = editingField?.options?.values?.[
      editingState?.editingOption?.optionIndex ?? -1
    ] as typeof option

    const editingOptionId = editingOption?.value ?? ''

    return {
      isHighlighted: !!option.value && option.value === editingOptionId,
      isHovered
    }
  }, [editingState, collection.uiSchema.rows, option])

  return useMemo(
    () => getHighlightStyles({ isHighlighted, isHovered, theme }),
    [isHighlighted, isHovered, theme]
  )
}

export default useOptionHighlightStyles
