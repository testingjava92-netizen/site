import { useMemo } from 'react'
import { getHighlightStyles } from '../utils/utils'
import { useCardContext } from './useCardContext'
import { useTheme } from '@mui/material'

const useFieldHighlightStyles = ({
  fieldId,
  fieldIndex,
  rowIndex
}: {
  fieldId: string
  fieldIndex: number
  rowIndex: number
}) => {
  const { editingState } = useCardContext()
  const theme = useTheme()

  return useMemo(() => {
    const isHovered = !!fieldId && editingState?.hoveredItem?._id === fieldId

    const isHighlighted = !!(
      !editingState?.editingOption &&
      editingState?.editingField &&
      rowIndex === editingState?.editingField?.rowIndex &&
      fieldIndex === editingState?.editingField?.fieldIndex
    )

    return getHighlightStyles({ isHighlighted, isHovered, theme })
  }, [fieldId, fieldIndex, rowIndex, editingState, theme])
}

export default useFieldHighlightStyles
