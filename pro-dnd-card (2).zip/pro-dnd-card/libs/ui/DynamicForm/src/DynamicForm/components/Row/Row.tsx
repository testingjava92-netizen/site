import React, { useMemo, useState } from 'react'
import { IFieldRow } from '../../types/types'
import RowContent from './components/RowContent'
import { useRowHighlightStyles } from '../../hooks/useRowHighlightStyles'
import { heightMap } from '../../constants'
import { SizeKey } from '../../types'
import { DEFAULT_ROW_HEIGHT } from '../../../DNDCardBuilder/constants'
import { Box, Collapse } from '@mui/material'
import CollapsibleButton from './components/CollapsibleButton'

const Row = ({
  row,
  rowIndex,
  disabled,
  rowHeight: basicRowHeight
}: {
  row: IFieldRow
  rowIndex: number
  disabled: boolean
  rowHeight?: SizeKey
}) => {
  const isCollapsible = row.collapsible

  const [isExpanded, setExpandedRow] = useState<boolean>(() => {
    return isCollapsible ? (row.defaultExpanded ?? false) : true
  })

  const highlightStyles = useRowHighlightStyles({ row, rowIndex })

  const rowHeight = useMemo(
    () => heightMap[row.height ?? basicRowHeight ?? DEFAULT_ROW_HEIGHT],
    [row.height, basicRowHeight]
  )

  return (
    <Box
      data-row-index={rowIndex}
      sx={{
        ...highlightStyles,

        ...(isCollapsible
          ? {
              outline: '1px solid',
              outlineColor: 'divider',
              borderRadius: 1
            }
          : {})
      }}
    >
      {isCollapsible && (
        <CollapsibleButton
          isExpanded={isExpanded}
          setExpandedRow={setExpandedRow}
          rowHeight={rowHeight}
          rowTitle={row.title ?? ''}
        />
      )}

      <Collapse
        {...(isCollapsible
          ? {
              in: isExpanded,
              timeout: 'auto',
              unmountOnExit: true,
              sx: { p: 2 }
            }
          : { in: true })}
      >
        <RowContent disabled={disabled} rowIndex={rowIndex} rowHeight={rowHeight} />
      </Collapse>
    </Box>
  )
}

export default Row
