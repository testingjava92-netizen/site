import { useState, useEffect } from 'react'
import {
  FormControl,
  FormLabel,
  FormHelperText,
  CircularProgress,
  Chip,
  Box,
  Typography,
  Tooltip
} from '@mui/material'
import { useFormContext, Controller } from 'react-hook-form'
import { ISelectLayoutField, IOption, FieldComponentProps } from '../../../types'
import { lazyLoaderMap } from '../../../constants/mappers'
import { getIconComponent } from '../../../utils/utils'
import { useQueryClient } from '@tanstack/react-query'

const LayoutChipsSelect = ({
  field,
  rowHeight,
  disabled = false
}: FieldComponentProps<ISelectLayoutField>) => {
  const { path, label, options, multiple = true } = field
  const { control } = useFormContext()
  const [loadedOptions, setLoadedOptions] = useState<IOption[]>(options?.values || [])
  const [loading, setLoading] = useState(false)
  const queryClient = useQueryClient()

  useEffect(() => {
    if (!options?.lazyValues && options?.values) {
      setLoadedOptions(options.values)
    }
  }, [options])

  useEffect(() => {
    if (options?.lazyValues && !options.values) {
      setLoading(true)
      const loaderFunction = lazyLoaderMap[options.lazyValues]
      if (loaderFunction) {
        loaderFunction(queryClient)
          .then((data) => {
            setLoadedOptions(data)
          })
          .catch((error) => {
            console.error('Error loading options:', error)
            setLoadedOptions([])
          })
          .finally(() => {
            setLoading(false)
          })
      } else {
        console.error(`Lazy loader not found for key: ${options.lazyValues}`)
        setLoading(false)
      }
    }
  }, [options, queryClient])

  const currentOptions = loadedOptions

  return (
    <Controller
      name={path}
      control={control}
      defaultValue={multiple ? [] : ''}
      render={({ field, fieldState: { error } }) => {
        const handleChipToggle = (optionValue: IOption['value']) => {
          if (disabled) return

          if (multiple) {
            // Ensure currentValue is always an array, even if field.value is string/undefined
            const currentValue = Array.isArray(field.value) ? field.value : []
            const isSelected = currentValue.includes(optionValue)

            if (isSelected) {
              // Remove from array
              const newValue = currentValue.filter((item) => item !== optionValue)
              field.onChange(newValue)
            } else {
              // Add to array
              field.onChange([...currentValue, optionValue])
            }
          } else {
            // Single select mode
            const isSelected = field.value === optionValue
            field.onChange(isSelected ? '' : optionValue)
          }
        }

        const isChipSelected = (optionValue: IOption['value']) => {
          if (multiple) {
            // Ensure currentValue is always an array, even if field.value is string/undefined
            const currentValue = Array.isArray(field.value) ? field.value : []
            return currentValue.includes(optionValue)
          } else {
            return field.value === optionValue
          }
        }

        return (
          <FormControl fullWidth error={!!error} sx={{ mt: 1 }}>
            {label ? (
              <FormLabel component='legend' sx={{ mb: 1, fontSize: '0.875rem', fontWeight: 500 }}>
                {label}
              </FormLabel>
            ) : null}

            {loading ? (
              <Box sx={{ display: 'flex', alignItems: 'center', p: 2 }}>
                <CircularProgress size={20} sx={{ mr: 1 }} />
                <Typography variant='body2'>טוען...</Typography>
              </Box>
            ) : (
              <Box
                sx={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: 1,
                  minHeight: '40px',
                  alignItems: 'flex-start'
                }}
              >
                {currentOptions.map((option) => {
                  const isSelected = isChipSelected(option.value)
                  const IconComponent = option.icon ? getIconComponent(option.icon) : null
                  const hasIcon = !!IconComponent

                  let chipLabel
                  let showTooltip = false

                  if (option.isIconOnly && hasIcon) {
                    chipLabel = <IconComponent />
                    showTooltip = true
                  } else if (hasIcon) {
                    chipLabel = (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <IconComponent />
                        {option.label}
                      </Box>
                    )
                  } else {
                    chipLabel = option.label
                  }

                  const chipElement = (
                    <Chip
                      key={`${option.value}`}
                      label={chipLabel}
                      clickable={!disabled}
                      disabled={disabled}
                      onClick={() => handleChipToggle(option.value)}
                      color={isSelected ? 'primary' : 'default'}
                      variant={isSelected ? 'filled' : 'outlined'}
                      sx={{
                        position: 'relative',
                        height: `calc(${rowHeight} - 16px)`,
                        borderRadius: `calc((${rowHeight} - 16px)/2)`,

                        ...(disabled
                          ? {
                              opacity: 0.6,
                              cursor: 'not-allowed',
                              '&:hover': {
                                transform: 'none',
                                boxShadow: 'none'
                              }
                            }
                          : isSelected
                            ? {
                                '&:hover': {
                                  transform: 'none',
                                  boxShadow: 'none',
                                  backgroundColor: 'primary.main',
                                  color: 'primary.contrastText'
                                }
                              }
                            : {
                                '&:hover': {
                                  boxShadow: (theme) => theme.shadows[2]
                                }
                              })
                      }}
                    />
                  )

                  return (
                    <Box key={`${option.value}`} sx={{ position: 'relative' }}>
                      {showTooltip ? (
                        <Tooltip title={option.label} placement='top'>
                          {chipElement}
                        </Tooltip>
                      ) : (
                        chipElement
                      )}
                      {option.badge ? (
                        <Chip
                          label={option.badge.text}
                          color={option.badge.color ?? 'default'}
                          size='small'
                          sx={{
                            position: 'absolute',
                            top: -5,
                            right: -5,
                            height: 20,
                            borderRadius: 0,
                            pointerEvents: 'none',
                            transform: 'rotate(-15deg)',
                            transformOrigin: 'top right',
                            '& .MuiChip-label': { px: 0.75, lineHeight: '20px' }
                          }}
                        />
                      ) : null}
                    </Box>
                  )
                })}
              </Box>
            )}

            {error && <FormHelperText>{error.message}</FormHelperText>}
          </FormControl>
        )
      }}
    />
  )
}

export default LayoutChipsSelect
