import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker'
import { useFormContext, Controller } from 'react-hook-form'
import { FieldComponentProps, IRestLayoutFields } from '../../../types'
import { DEFAULT_DATE_TIME_FORMAT } from '../../../../DNDCardBuilder/constants'

const LayoutDateTimePicker = ({
  field,
  rowHeight,
  disabled = false
}: FieldComponentProps<IRestLayoutFields>) => {
  const { path, label, placeholder } = field
  const { control } = useFormContext()

  return (
    <Controller
      name={path}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <DateTimePicker
          {...field}
          value={field.value || null}
          onChange={(newValue) => field.onChange(newValue)}
          disabled={disabled}
          label={label}
          format={DEFAULT_DATE_TIME_FORMAT}
          views={['year', 'month', 'day', 'hours', 'minutes']}
          ampm={false}
          slotProps={{
            textField: {
              placeholder: placeholder,
              fullWidth: true,
              error: !!error,
              helperText: error?.message,
              variant: 'outlined',
              disabled: disabled,
              InputLabelProps: {
                shrink: true
              },
              InputProps: {
                sx: {
                  height: rowHeight
                }
              }
            }
          }}
        />
      )}
    />
  )
}

export default LayoutDateTimePicker
