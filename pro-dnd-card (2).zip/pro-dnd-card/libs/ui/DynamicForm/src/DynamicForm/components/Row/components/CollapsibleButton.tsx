import { ExpandLess, ExpandMore } from '@mui/icons-material'
import { Typography, Button } from '@mui/material'
import { SetStateAction, Dispatch } from 'react'

const CollapsibleButton = ({
  isExpanded,
  setExpandedRow,
  rowHeight,
  rowTitle
}: {
  isExpanded: boolean
  setExpandedRow: Dispatch<SetStateAction<boolean>>
  rowHeight: string
  rowTitle: string
}) => {
  return (
    <Button
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-start',
        py: 2,
        width: '100%',
        height: rowHeight,
        backgroundColor: isExpanded ? 'divider' : 'transparent'
      }}
      variant='text'
      color='inherit'
      onClick={() => setExpandedRow((prev) => !prev)}
      startIcon={isExpanded ? <ExpandLess /> : <ExpandMore />}
    >
      {rowTitle && (
        <Typography variant='subtitle2' sx={{ fontWeight: 'medium' }}>
          {rowTitle}
        </Typography>
      )}
    </Button>
  )
}

export default CollapsibleButton
