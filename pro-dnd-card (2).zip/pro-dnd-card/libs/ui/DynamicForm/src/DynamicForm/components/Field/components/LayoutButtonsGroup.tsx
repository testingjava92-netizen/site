import {
  FormControl,
  ToggleButtonGroup,
  ToggleButton,
  FormHelperText,
  Box,
  Tooltip,
  Chip
} from '@mui/material'
import { useFormContext, Controller } from 'react-hook-form'
import { FieldComponentProps, IOption, ISelectLayoutField } from '../../../types'
import { getIconComponent, evaluateCondition } from '../../../utils/utils'
import useOptionHighlightStyles from '../../../hooks/useOptionHighlightStyles'
import { useCardContext } from '../../../hooks/useCardContext'
import { useMemo } from 'react'

const ButtonGroup = ({ option, disabled = false }: { option: IOption; disabled?: boolean }) => {
  const IconComponent = option.icon ? getIconComponent(option.icon) : null
  const hasIcon = !!IconComponent
  const highlightStyles = useOptionHighlightStyles({ option })
  const { collection } = useCardContext()
  const { watch } = useFormContext()
  const formValues = watch()

  const isOptionDisabled =
    disabled || evaluateCondition(option.disabled, formValues, collection.uiSchema.context)

  let buttonContent
  let showTooltip = false

  if (option.isIconOnly && hasIcon) {
    buttonContent = <IconComponent />
    showTooltip = true
  } else if (hasIcon) {
    buttonContent = (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <IconComponent />
        {option.label}
      </Box>
    )
  } else {
    buttonContent = option.label
  }

  return (
    <ToggleButton
      key={`${option.value}`}
      value={option.value}
      disabled={isOptionDisabled}
      sx={{
        position: 'relative',
        flex: 1,
        whiteSpace: 'nowrap',
        ...highlightStyles
      }}
    >
      {showTooltip ? (
        <Tooltip title={option.label} placement='top'>
          <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 1 }}>{buttonContent}</Box>
        </Tooltip>
      ) : (
        <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 1 }}>{buttonContent}</Box>
      )}
      {option.badge ? (
        <Chip
          label={option.badge.text}
          color={option.badge.color ?? 'default'}
          size='small'
          sx={{
            position: 'absolute',
            top: -5,
            right: -5,
            height: 20,
            borderRadius: 0,
            pointerEvents: 'none',
            transform: 'rotate(-15deg)',
            transformOrigin: 'top right',
            '& .MuiChip-label': { px: 0.75, lineHeight: '20px' }
          }}
        />
      ) : null}
    </ToggleButton>
  )
}

const ButtonsGroup = ({
  field,
  rowHeight,
  disabled = false
}: FieldComponentProps<ISelectLayoutField>) => {
  const { path, label, options, multiple = false } = field
  const { control, watch } = useFormContext()
  const { collection } = useCardContext()
  const formValues = watch()

  // Filter options based on hidden/disabled conditions
  const currentOptions = useMemo(() => {
    return (options?.values || []).filter((option) => {
      const isHidden = evaluateCondition(option.hidden, formValues, collection.uiSchema.context)
      return !isHidden
    })
  }, [options?.values, formValues, collection.uiSchema.context])

  return (
    <Controller
      name={path}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <FormControl
          component='fieldset'
          error={!!error}
          sx={{
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            flex: 1
          }}
        >
          <Box
            sx={{
              flex: 1,
              display: 'flex'
            }}
          >
            <ToggleButtonGroup
              {...field}
              exclusive={!multiple}
              disabled={disabled}
              value={multiple ? (field.value ?? []) : (field.value ?? '')}
              onChange={(_, newValue) => {
                if (multiple) {
                  // For multiple selection, newValue is an array
                  field.onChange(newValue ?? [])
                } else {
                  // For single selection, only update if newValue is not null
                  if (newValue !== null) {
                    field.onChange(newValue)
                  }
                }
              }}
              aria-label={label}
              sx={{
                width: '100%',
                display: 'flex',

                flex: 1,
                overflowY: 'auto',
                alignItems: 'stretch',
                overflow: 'visible',

                '& .MuiToggleButton-root': {
                  height: rowHeight,
                  flex: 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  textTransform: 'none',
                  px: 2,
                  py: 1,
                  border: '1px solid',
                  borderColor: 'divider',
                  color: 'text.primary',
                  '&:not(.Mui-selected):hover': {
                    backgroundColor: 'action.hover',
                    borderColor: 'divider',
                    color: 'text.primary'
                  },
                  '&:not(:first-of-type)': {
                    borderLeft: '1px solid',
                    borderLeftColor: 'divider'
                  },
                  '&.Mui-selected': {
                    backgroundColor: 'primary.main',
                    color: 'primary.contrastText',
                    borderColor: 'primary.main'
                  },
                  '&.Mui-selected:hover': {
                    backgroundColor: 'primary.main',
                    borderColor: 'primary.main'
                  },
                  '&.Mui-selected.Mui-focusVisible': {
                    backgroundColor: 'primary.dark',
                    borderColor: 'primary.dark'
                  },
                  '&.Mui-disabled': {
                    backgroundColor: 'action.disabledBackground',
                    color: 'text.disabled',
                    borderColor: 'divider'
                  },
                  '&.Mui-selected.Mui-disabled': {
                    backgroundColor: 'action.disabledBackground',
                    color: 'text.disabled',
                    borderColor: 'divider'
                  }
                }
              }}
            >
              {currentOptions.map((option) => {
                return <ButtonGroup key={`${option.value}`} option={option} disabled={disabled} />
              })}
            </ToggleButtonGroup>
          </Box>
          {error && <FormHelperText>{error.message}</FormHelperText>}
        </FormControl>
      )}
    />
  )
}

export default ButtonsGroup
