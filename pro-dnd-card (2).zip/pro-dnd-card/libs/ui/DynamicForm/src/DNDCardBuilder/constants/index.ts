import { ConditionGroup, DefaultSchema, Paths, SingleCondition } from '../../DynamicForm/types'
import { ConditionOperator, LogicalOperator, SizeKey } from '../../DynamicForm/types/enums'
import {
  CategoryStates,
  CategoryType,
  RowCategoryType,
  RowsCategoryType,
  OptionCategoryType
} from '../types'

export * from './labels'

// Layout defaults
export const DEFAULT_GAP = SizeKey.S3 // Default gap between fields (0 = no gap)
export const DEFAULT_PX = SizeKey.S2 // Default horizontal padding (left/right)
export const DEFAULT_PY = SizeKey.S4 // Default vertical padding (top/bottom)
export const DEFAULT_DATE_FORMAT = 'dd/MM/yyyy' // Default date format
export const DEFAULT_DATE_TIME_FORMAT = 'dd/MM/yyyy HH:mm' // Default date format
export const DEFAULT_ROW_HEIGHT: SizeKey = SizeKey.S3
export const DEFAULT_WIDTH = 12

export const initialCategoryStates: CategoryStates = {
  field: CategoryType.Basic,
  row: RowCategoryType.Fields,
  rows: RowsCategoryType.Rows,
  option: OptionCategoryType.General
}

export const DEFAULT_SINGLE_CONDITION: SingleCondition<DefaultSchema> = {
  field: '' as Paths<DefaultSchema>,
  isContext: false,
  operator: ConditionOperator.EQUALS,
  value: ''
}

export const DEFAULT_MULTIPLE_CONDITION: ConditionGroup<DefaultSchema> = {
  operator: LogicalOperator.AND,
  conditions: [DEFAULT_SINGLE_CONDITION]
}
