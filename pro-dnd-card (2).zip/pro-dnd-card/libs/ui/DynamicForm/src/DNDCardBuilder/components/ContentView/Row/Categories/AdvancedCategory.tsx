import React from 'react'
import { Divider, Stack } from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../../constants'
import BooleanOrConditionsManager from '../../Condition/BooleanOrConditionsManager'
import { ConditionField, ConditionGroup } from '../../../../../DynamicForm/types'

interface AdvancedCategoryProps {
  rowIndex: number
}

const AdvancedCategory: React.FC<AdvancedCategoryProps> = ({ rowIndex }) => {
  const { selectedCollection, setSelectedCollection, fieldPathOptions, navigateToEditCondition } =
    useDNDCardBuilderContext()

  const row = selectedCollection.uiSchema.rows[rowIndex]

  const updateRow = (updates: Record<string, unknown>) => {
    if (!row) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((rowItem, index) =>
          index === rowIndex ? { ...rowItem, ...updates } : rowItem
        )
      }
    }))
  }

  if (!row) {
    return null
  }

  return (
    <Stack spacing={3}>
      <BooleanOrConditionsManager
        label={DND_CARD_BUILDER_LABELS.ROW_HIDDEN}
        value={(row as { hidden?: boolean | ConditionGroup })?.hidden}
        onChange={(value) => updateRow({ hidden: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              conditionField: ConditionField.hidden
            })
          }
        }}
      />

      <Divider />

      <BooleanOrConditionsManager
        label={DND_CARD_BUILDER_LABELS.ROW_DISABLED}
        value={(row as { disabled?: boolean | ConditionGroup })?.disabled}
        onChange={(value) => updateRow({ disabled: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              conditionField: ConditionField.disabled
            })
          }
        }}
      />
    </Stack>
  )
}

export default AdvancedCategory
