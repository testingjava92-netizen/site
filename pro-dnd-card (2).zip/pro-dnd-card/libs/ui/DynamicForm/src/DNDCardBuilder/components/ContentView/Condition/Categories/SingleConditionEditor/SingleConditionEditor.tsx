import { useState } from 'react'
import {
  Box,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Switch,
  FormControlLabel,
  Autocomplete,
  Stack
} from '@mui/material'
import {
  SingleCondition,
  ConditionOperator,
  ConditionValue,
  DefaultSchema
} from '../../../../../../DynamicForm/types'
import { useDNDCardBuilderContext } from '../../../../../utils/context'
import SingleConditionValueInput from './SingleConditionValueInput'

interface SingleConditionEditorProps<Schema = DefaultSchema> {
  condition: SingleCondition<Schema>
  onChange: (condition: SingleCondition<Schema>) => void
}

const conditionOperatorLabels: Record<ConditionOperator, string> = {
  [ConditionOperator.EQUALS]: 'שווה ל',
  [ConditionOperator.NOT_EQUALS]: 'לא שווה ל',
  [ConditionOperator.GREATER_THAN]: 'גדול מ',
  [ConditionOperator.LESS_THAN]: 'קטן מ',
  [ConditionOperator.GREATER_OR_EQUAL]: 'גדול או שווה ל',
  [ConditionOperator.LESS_OR_EQUAL]: 'קטן או שווה ל',
  [ConditionOperator.CONTAINS]: 'מכיל',
  [ConditionOperator.NOT_CONTAINS]: 'לא מכיל',
  [ConditionOperator.IS_EMPTY]: 'ריק',
  [ConditionOperator.IS_NOT_EMPTY]: 'לא ריק',
  [ConditionOperator.IS_TRUE]: 'אמת',
  [ConditionOperator.IS_FALSE]: 'שקר'
}

// Operators that don't need a value input
const VALUE_LESS_OPERATORS = [
  ConditionOperator.IS_EMPTY,
  ConditionOperator.IS_NOT_EMPTY,
  ConditionOperator.IS_TRUE,
  ConditionOperator.IS_FALSE
]

// Operators that work with numeric values
const NUMERIC_OPERATORS = [
  ConditionOperator.GREATER_THAN,
  ConditionOperator.LESS_THAN,
  ConditionOperator.GREATER_OR_EQUAL,
  ConditionOperator.LESS_OR_EQUAL
]

// Operators that only work with boolean values
const BOOLEAN_ONLY_OPERATORS = [ConditionOperator.IS_TRUE, ConditionOperator.IS_FALSE]

type ValueType = 'string' | 'number' | 'boolean'

const getValueType = (value: ConditionValue | undefined): ValueType => {
  if (typeof value === 'boolean') return 'boolean'
  if (typeof value === 'number') return 'number'
  return 'string'
}

const SingleConditionEditor = <Schema extends DefaultSchema = DefaultSchema>({
  condition,
  onChange
}: SingleConditionEditorProps<Schema>) => {
  const { fieldPathOptions: availableFields, contextPathOptions } = useDNDCardBuilderContext()
  const [valueType, setValueType] = useState<ValueType>(() => getValueType(condition.value))

  const handleFieldChange = (field: string) => {
    if ('isContext' in condition && condition.isContext) {
      // Context condition
      onChange({
        field: field,
        isContext: true,
        operator: condition.operator,
        value: condition.value,
        title: condition.title
      } as SingleCondition<Schema>)
    } else {
      // Schema field condition
      onChange({
        field: field as SingleCondition<Schema>['field'],
        isContext: false,
        operator: condition.operator,
        value: condition.value,
        title: condition.title
      } as SingleCondition<Schema>)
    }
  }

  const handleIsContextChange = (isContext: boolean) => {
    if (isContext) {
      // Converting to context condition
      onChange({
        field: String(condition.field),
        isContext: true,
        operator: condition.operator,
        value: condition.value,
        title: condition.title
      } as SingleCondition<Schema>)
    } else {
      // Converting to schema field condition
      onChange({
        field: String(condition.field) as SingleCondition<Schema>['field'],
        isContext: false,
        operator: condition.operator,
        value: condition.value,
        title: condition.title
      } as SingleCondition<Schema>)
    }
  }

  const handleOperatorChange = (operator: ConditionOperator) => {
    const updatedCondition = {
      ...condition,
      operator
    }

    // Reset value for operators that don't need a value
    if (VALUE_LESS_OPERATORS.includes(operator)) {
      updatedCondition.value = undefined
      setValueType('string') // Reset to default
    }
    // For boolean-only operators, convert existing value to boolean or set default
    else if (BOOLEAN_ONLY_OPERATORS.includes(operator)) {
      if (condition.value === undefined || condition.value === null) {
        updatedCondition.value = false
      } else {
        // Convert existing value to boolean more intelligently
        const currentValue = condition.value
        if (typeof currentValue === 'boolean') {
          updatedCondition.value = currentValue
        } else if (typeof currentValue === 'string') {
          updatedCondition.value = currentValue.toLowerCase() === 'true' || currentValue === '1'
        } else if (typeof currentValue === 'number') {
          updatedCondition.value = currentValue !== 0
        } else {
          updatedCondition.value = false
        }
      }
      setValueType('boolean')
    }
    // For numeric operators, try to convert existing value or set intelligent default
    else if (NUMERIC_OPERATORS.includes(operator)) {
      if (condition.value === undefined || condition.value === null) {
        updatedCondition.value = '' // Let user enter value instead of defaulting to 0
      } else if (typeof condition.value === 'string') {
        const num = parseFloat(condition.value.trim())
        updatedCondition.value = isNaN(num) ? '' : num
      } else if (typeof condition.value === 'boolean') {
        updatedCondition.value = condition.value ? 1 : 0
      } else if (typeof condition.value === 'number') {
        updatedCondition.value = condition.value
      }
      setValueType('number')
    }
    // For other operators (EQUALS, NOT_EQUALS, CONTAINS, NOT_CONTAINS), keep existing value or set default
    else if (!VALUE_LESS_OPERATORS.includes(operator)) {
      if (condition.value === undefined || condition.value === null) {
        updatedCondition.value = ''
      }
      // Keep current value type if reasonable, otherwise default to string
      if (typeof condition.value === 'string' || condition.value === undefined) {
        setValueType('string')
      } else if (typeof condition.value === 'number') {
        setValueType('number')
      } else if (typeof condition.value === 'boolean') {
        setValueType('boolean')
      }
    }

    onChange(updatedCondition)
  }

  const handleValueChange = (value: ConditionValue) => {
    onChange({
      ...condition,
      value
    })
  }

  const handleValueTypeChange = (newType: ValueType) => {
    setValueType(newType)

    // Convert existing value to new type intelligently
    let convertedValue: ConditionValue = ''

    if (newType === 'boolean') {
      const currentValue = condition.value
      if (typeof currentValue === 'boolean') {
        convertedValue = currentValue
      } else if (typeof currentValue === 'string') {
        const lowerValue = currentValue.toLowerCase().trim()
        convertedValue = lowerValue === 'true' || lowerValue === '1' || lowerValue === 'yes'
      } else if (typeof currentValue === 'number') {
        convertedValue = currentValue !== 0
      } else {
        convertedValue = false
      }
    } else if (newType === 'number') {
      const currentValue = condition.value
      if (typeof currentValue === 'number') {
        convertedValue = currentValue
      } else if (typeof currentValue === 'string') {
        const num = parseFloat(currentValue.trim())
        convertedValue = isNaN(num) ? '' : num
      } else if (typeof currentValue === 'boolean') {
        convertedValue = currentValue ? 1 : 0
      } else {
        convertedValue = ''
      }
    } else {
      // Convert to string
      if (condition.value === null || condition.value === undefined) {
        convertedValue = ''
      } else {
        convertedValue = String(condition.value)
      }
    }

    handleValueChange(convertedValue)
  }

  const needsValueInput = !VALUE_LESS_OPERATORS.includes(condition.operator)
  const isBooleanOnlyOperator = BOOLEAN_ONLY_OPERATORS.includes(condition.operator)
  const canChooseValueType = needsValueInput && !isBooleanOnlyOperator

  return (
    <Box sx={{ bgcolor: 'background.default' }}>
      <Stack spacing={3}>
        {/* Field input with context toggle on the same row */}
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
          <Box sx={{ flex: 1 }}>
            {'isContext' in condition && condition.isContext === true ? (
              <Autocomplete
                freeSolo
                options={contextPathOptions}
                value={String(condition.field || '')}
                onChange={(_, newValue) => {
                  if (typeof newValue === 'string') {
                    handleFieldChange(newValue)
                  }
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label='שדה מהקונטקסט'
                    onBlur={(e) => handleFieldChange(e.target.value)}
                    fullWidth
                    placeholder='user.role, session.userId, etc.'
                    helperText='בחר או הכנס נתיב לשדה בקונטקסט'
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'background.default'
                      }
                    }}
                  />
                )}
              />
            ) : (
              <Autocomplete
                freeSolo
                options={availableFields}
                value={String(condition.field || '')}
                onChange={(_, newValue) => {
                  if (typeof newValue === 'string') {
                    handleFieldChange(newValue)
                  }
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label='שדה מהסכמה'
                    onBlur={(e) => handleFieldChange(e.target.value)}
                    fullWidth
                    helperText='בחר או הכנס שדה מהטופס'
                  />
                )}
              />
            )}
          </Box>

          <Box sx={{ pt: 1, display: 'flex', alignItems: 'center' }}>
            <FormControlLabel
              control={
                <Switch
                  checked={'isContext' in condition && condition.isContext === true}
                  onChange={(e) => handleIsContextChange(e.target.checked)}
                />
              }
              label={
                <Typography variant='caption' sx={{ fontWeight: 500 }}>
                  {'isContext' in condition && condition.isContext === true ? 'קונטקסט' : 'סכמה'}
                </Typography>
              }
              sx={{ m: 0 }}
            />
          </Box>
        </Box>

        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: 2
          }}
        >
          <Box sx={{ flex: 1 }}>
            <FormControl fullWidth>
              <InputLabel>אופרטור</InputLabel>
              <Select
                value={condition.operator}
                label='אופרטור'
                onChange={(e) => handleOperatorChange(e.target.value as ConditionOperator)}
              >
                {Object.entries(conditionOperatorLabels).map(([value, label]) => (
                  <MenuItem key={value} value={value}>
                    {label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          {needsValueInput && (
            <SingleConditionValueInput
              condition={condition}
              valueType={valueType}
              canChooseValueType={canChooseValueType}
              needsValueInput={needsValueInput}
              onValueTypeChange={handleValueTypeChange}
              onValueChange={handleValueChange}
            />
          )}
        </Box>
      </Stack>
    </Box>
  )
}

export default SingleConditionEditor
