import React from 'react'
import {
  Stack,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Box,
  Typography
} from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import WidthPicker from '../../EditField/WidthPicker'
import {
  ILayoutField,
  IRadioLayoutField,
  FieldComponentType,
  RadioOrientation
} from '../../../../../DynamicForm/types'

interface LayoutCategoryProps {
  rowIndex: number
  fieldIndex: number
}

const LayoutCategory: React.FC<LayoutCategoryProps> = ({ rowIndex, fieldIndex }) => {
  const { setSelectedCollection, selectedCollection } = useDNDCardBuilderContext()

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[fieldIndex] as ILayoutField
  const isRadioField = field?.component === FieldComponentType.inputRadio
  const radioField = isRadioField ? (field as IRadioLayoutField) : null

  const updateField = (updates: Record<string, unknown>) => {
    if (!field) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((row, index) =>
          index === rowIndex
            ? {
                ...row,
                fields: row.fields?.map((fieldItem) =>
                  fieldItem._id === field._id ? { ...fieldItem, ...updates } : fieldItem
                )
              }
            : row
        )
      }
    }))
  }

  if (!field) {
    return null
  }

  return (
    <Stack spacing={3}>
      <WidthPicker value={field.width} onChange={(width) => updateField({ width })} />

      {/* Radio-specific controls */}
      {isRadioField && radioField && (
        <Box sx={{ p: 3, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
          <Typography variant='subtitle2' sx={{ mb: 2 }}>
            הגדרות רדיו
          </Typography>
          <FormControl component='fieldset'>
            <FormLabel component='legend' sx={{ mb: 1 }}>
              כיוון תצוגה
            </FormLabel>
            <RadioGroup
              value={radioField.orientation || RadioOrientation.VERTICAL}
              onChange={(e) => {
                const orientation = e.target.value as RadioOrientation
                updateField({ ...radioField, orientation })
              }}
              row
            >
              <FormControlLabel
                value={RadioOrientation.VERTICAL}
                control={<Radio size='small' />}
                label='אנכי'
              />
              <FormControlLabel
                value={RadioOrientation.HORIZONTAL}
                control={<Radio size='small' />}
                label='אופקי'
              />
            </RadioGroup>
          </FormControl>
        </Box>
      )}
    </Stack>
  )
}

export default LayoutCategory
