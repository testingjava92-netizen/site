import React from 'react'
import { Box } from '@mui/material'
import BasicCategory from './Categories/BasicCategory'
import LayoutCategory from './Categories/LayoutCategory'
import ValidationCategory from './Categories/ValidationCategory'
import InputCategory from './Categories/InputCategory'
import OptionsCategory from './Categories/OptionsCategory'
import AdvancedCategory from './Categories/AdvancedCategory'
import { CategoryType } from '../../../types'

interface EditFieldCategoryProps {
  selectedCategory: string
  rowIndex: number
  fieldIndex: number
}

const EditFieldCategory: React.FC<EditFieldCategoryProps> = ({
  selectedCategory,
  rowIndex,
  fieldIndex
}) => {
  return (
    <Box
      sx={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        p: selectedCategory === CategoryType.Options ? 0 : 4
      }}
    >
      {selectedCategory === CategoryType.Basic && (
        <BasicCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
      {selectedCategory === CategoryType.Layout && (
        <LayoutCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
      {selectedCategory === CategoryType.Validation && (
        <ValidationCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
      {selectedCategory === CategoryType.Input && (
        <InputCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
      {selectedCategory === CategoryType.Options && (
        <OptionsCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
      {selectedCategory === CategoryType.Advanced && (
        <AdvancedCategory rowIndex={rowIndex} fieldIndex={fieldIndex} />
      )}
    </Box>
  )
}

export default EditFieldCategory
