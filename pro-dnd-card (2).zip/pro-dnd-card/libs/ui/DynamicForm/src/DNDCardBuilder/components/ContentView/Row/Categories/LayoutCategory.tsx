import React from 'react'
import { Stack, FormControlLabel, Switch, FormControl, Typography, FormLabel } from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DEFAULT_GAP, DEFAULT_ROW_HEIGHT, DND_CARD_BUILDER_LABELS } from '../../../../constants'
import { SizeKey } from '../../../../../DynamicForm/types'
import AutoManualSlider from '../../../AutoManualSlider'
import { heightMap } from '../../../../../DynamicForm/constants'

interface LayoutCategoryProps {
  rowIndex: number
}

const LayoutCategory: React.FC<LayoutCategoryProps> = ({ rowIndex }) => {
  const { selectedCollection, setSelectedCollection } = useDNDCardBuilderContext()

  const row = selectedCollection.uiSchema.rows[rowIndex]

  const updateRow = (updates: Record<string, unknown>) => {
    if (!row) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((rowItem, index) =>
          index === rowIndex ? { ...rowItem, ...updates } : rowItem
        )
      }
    }))
  }

  const handleGapChange = (value: number | undefined) => {
    updateRow({ gap: value as SizeKey | undefined })
  }

  const handleHeightChange = (value: number | undefined) => {
    updateRow({ height: value as SizeKey | undefined })
  }

  if (!row) {
    return null
  }

  return (
    <Stack spacing={5}>
      <AutoManualSlider
        label='רווח בין שדות'
        value={row?.gap}
        initialValue={DEFAULT_GAP}
        onChange={handleGapChange}
        min={0}
        max={40}
        valueLabelFormat={(value: number) => {
          const gapInPx = value * 8
          return `S${value} (${gapInPx}px)`
        }}
        displayFormat={(value: number) => `רווח נוכחי: S${value} (${value * 8}px)`}
      />

      <AutoManualSlider
        label='גובה שורה'
        value={row?.height}
        initialValue={DEFAULT_ROW_HEIGHT}
        onChange={handleHeightChange}
        min={0}
        max={20}
        valueLabelFormat={(value: number) => heightMap[value as SizeKey]}
        displayFormat={(value: number) => `גובה נוכחי: S${value} (${heightMap[value as SizeKey]})`}
      />

      <FormControl fullWidth sx={{ mb: 0 }}>
        <FormLabel component='legend'>
          <Typography variant='subtitle2' sx={{ mb: 1 }}>
            {DND_CARD_BUILDER_LABELS.ROW_COLLAPSIBLE}
          </Typography>
        </FormLabel>

        <FormControlLabel
          control={
            <Switch
              size='small'
              checked={Boolean(row?.collapsible)}
              onChange={(e) => updateRow({ collapsible: e.target.checked })}
            />
          }
          label={row?.collapsible ? DND_CARD_BUILDER_LABELS.ON : DND_CARD_BUILDER_LABELS.OFF}
        />

        {row?.collapsible && (
          <FormControlLabel
            sx={{ mt: 1 }}
            control={
              <Switch
                size='small'
                checked={Boolean(row?.defaultExpanded)}
                onChange={(e) => updateRow({ defaultExpanded: e.target.checked })}
              />
            }
            label={DND_CARD_BUILDER_LABELS.ROW_DEFAULT_EXPANDED}
          />
        )}
      </FormControl>
    </Stack>
  )
}

export default LayoutCategory
