import React, { useMemo } from 'react'
import { Box, Typography, IconButton } from '@mui/material'
import ArrowBackIcon from '@mui/icons-material/ArrowBack'
import { useDNDCardBuilderContext } from '../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../constants'
import { ViewType } from '../types'

const Header: React.FC = () => {
  const {
    currentView,
    navigateBackToRow,
    navigateBackToRows,
    navigateBackToField,
    navigateBackFromCondition
  } = useDNDCardBuilderContext()

  const { title, onBack } = useMemo(() => {
    if (currentView === ViewType.EditRow) {
      return {
        title: DND_CARD_BUILDER_LABELS.EDIT_ROW_TITLE,
        onBack: navigateBackToRows
      }
    }

    if (currentView === ViewType.EditField) {
      return {
        title: DND_CARD_BUILDER_LABELS.EDIT_FIELD_TITLE,
        onBack: navigateBackToRow
      }
    }

    if (currentView === ViewType.EditOption) {
      return {
        title: DND_CARD_BUILDER_LABELS.EDIT_OPTION_TITLE,
        onBack: navigateBackToField
      }
    }

    if (currentView === ViewType.EditCondition) {
      return {
        title: DND_CARD_BUILDER_LABELS.EDIT_CONDITION_TITLE,
        onBack: navigateBackFromCondition
      }
    }

    return {
      title: DND_CARD_BUILDER_LABELS.EDIT_ROWS_TITLE,
      onBack: undefined
    }
  }, [
    currentView,
    navigateBackToRow,
    navigateBackToRows,
    navigateBackToField,
    navigateBackFromCondition
  ])

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        py: 2,
        px: onBack ? 1 : 4,
        backgroundColor: 'primary.dark',
        gap: 1
      }}
    >
      {onBack && (
        <IconButton onClick={onBack} sx={{ p: 0.5, color: 'primary.contrastText' }}>
          <ArrowBackIcon sx={{ transform: 'rotate(180deg)' }} />
        </IconButton>
      )}
      <Typography variant='h6' sx={{ color: 'primary.contrastText' }}>
        {title}
      </Typography>
    </Box>
  )
}

export default Header
