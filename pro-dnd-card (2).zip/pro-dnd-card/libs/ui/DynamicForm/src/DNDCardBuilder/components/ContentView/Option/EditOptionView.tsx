import React from 'react'
import SettingsIcon from '@mui/icons-material/Settings'
import TuneIcon from '@mui/icons-material/Tune'
import { useDNDCardBuilderContext } from '../../../utils/context'
import MenuList, { MenuCategory } from '../MenuList'
import EditOptionCategory from './EditOptionCategory'
import { OptionCategoryType } from '../../../types'

const categories: MenuCategory[] = [
  { id: 'general', label: 'כללי', icon: <SettingsIcon /> },
  { id: 'advanced', label: 'מתקדם', icon: <TuneIcon /> }
]

const EditOptionView: React.FC = () => {
  const { selectedCollection, categoryStates, updateOptionCategory, editingOption } =
    useDNDCardBuilderContext()
  if (!editingOption) {
    return null
  }
  const { rowIndex, fieldIndex, optionIndex } = editingOption
  const selectedCategory = categoryStates.option

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[fieldIndex]
  const option = (field as { options?: { values?: unknown[] } })?.options?.values?.[optionIndex]

  if (!field || !option) {
    return null
  }

  const availableCategories: OptionCategoryType[] = [
    OptionCategoryType.General,
    OptionCategoryType.Advanced
  ]

  return (
    <>
      <MenuList
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={(categoryId) => updateOptionCategory(categoryId as OptionCategoryType)}
        availableCategories={availableCategories}
      />

      <EditOptionCategory
        selectedCategory={selectedCategory}
        rowIndex={rowIndex}
        fieldIndex={fieldIndex}
        optionIndex={optionIndex}
      />
    </>
  )
}

export default EditOptionView
