import React from 'react'
import SettingsIcon from '@mui/icons-material/Settings'
import LayoutIcon from '@mui/icons-material/ViewQuilt'
import TuneIcon from '@mui/icons-material/Tune'
import ListIcon from '@mui/icons-material/List'
import { useDNDCardBuilderContext } from '../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../constants'
import MenuList, { MenuCategory } from '../MenuList'
import EditRowCategory from './EditRowCategory'
import { RowCategoryType } from '../../../types'

const categories: MenuCategory[] = [
  { id: 'fields', label: 'שדות', icon: <ListIcon /> },
  { id: 'settings', label: DND_CARD_BUILDER_LABELS.SETTINGS_SECTION, icon: <SettingsIcon /> },
  { id: 'layout', label: 'פריסה', icon: <LayoutIcon /> },
  { id: 'advanced', label: 'מתקדם', icon: <TuneIcon /> }
]

const EditRowView: React.FC = () => {
  const { selectedCollection, categoryStates, updateRowCategory, editingRow } =
    useDNDCardBuilderContext()
  const selectedCategory = categoryStates.row
  if (!editingRow) {
    return null
  }

  const row = selectedCollection.uiSchema.rows[editingRow.rowIndex]

  if (!row) {
    return null
  }

  return (
    <>
      <MenuList
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={(categoryId) => updateRowCategory(categoryId as RowCategoryType)}
      />

      <EditRowCategory selectedCategory={selectedCategory} rowIndex={editingRow.rowIndex} />
    </>
  )
}

export default EditRowView
