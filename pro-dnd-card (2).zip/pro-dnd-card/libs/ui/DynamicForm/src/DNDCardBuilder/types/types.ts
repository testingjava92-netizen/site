import { Dispatch, SetStateAction } from 'react'
import { ICollection } from '../../DynamicForm/types'
import { EditingState } from '../../DynamicForm/types'
import { CategoryType, OptionCategoryType, RowCategoryType, RowsCategoryType } from './enums'

export interface CategoryStates {
  field: CategoryType
  row: RowCategoryType
  rows: RowsCategoryType
  option: OptionCategoryType
}

export interface DNDCardBuilderProps {
  selectedCollection: ICollection | null
  setSelectedCollection: Dispatch<SetStateAction<ICollection>>
  editingState: EditingState
  setEditingState: (state: EditingState) => void
}

export interface DNDCardBuilderProviderProps
  extends Omit<DNDCardBuilderProps, 'selectedCollection' | 'setSelectedCollection'> {
  selectedCollection: ICollection
  setSelectedCollection: Dispatch<SetStateAction<ICollection>>
}
