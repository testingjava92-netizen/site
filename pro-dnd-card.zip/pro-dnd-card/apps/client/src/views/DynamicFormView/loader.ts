export const initialData = async () => {
  return { test: 'some initial data' }
}
