import styles from './Table.module.css'

export function Table() {
  return (
    <div className={styles['container']}>
      <h1>Welcome to Table!</h1>
    </div>
  )
}

export default Table
