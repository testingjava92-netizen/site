import { Typography } from '@mui/material'

export function NoMoreDataConent() {
  return (
    <Typography variant='body2' color='text.secondary'>
      No more data to load
    </Typography>
  )
}
