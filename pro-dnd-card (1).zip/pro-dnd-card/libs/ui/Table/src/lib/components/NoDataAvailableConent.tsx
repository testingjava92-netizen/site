import { Typography } from '@mui/material'

export function NoDataAvailableConent() {
  return (
    <Typography variant='body1' color='text.secondary'>
      No data available
    </Typography>
  )
}
