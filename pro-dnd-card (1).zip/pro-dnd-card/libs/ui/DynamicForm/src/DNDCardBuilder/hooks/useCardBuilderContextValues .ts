import { useCallback, useMemo } from 'react'
import {
  EditingFieldInfo,
  EditingOptionInfo,
  EditingRowInfo,
  EditingConditionInfo,
  FieldComponentType,
  HoveredInfo,
  IFieldRow,
  ILayoutField,
  WidthKey
} from '../../DynamicForm/types'
import { UnknownRecord } from '../../DynamicForm/types'
import { DND_CARD_BUILDER_LABELS } from '../constants'
import {
  ViewType,
  RowCategoryType,
  CategoryType,
  OptionCategoryType,
  RowsCategoryType,
  DNDCardBuilderProviderProps
} from '../types'
import { v4 as uuidv4 } from 'uuid'
import { initialCategoryStates } from '../constants'

export const useCardBuilderContextValues = ({
  setSelectedCollection,
  selectedCollection,
  editingState,
  setEditingState
}: DNDCardBuilderProviderProps) => {
  // View management state - now managed through editingState

  // Helper function to update hoveredItem
  const setHoveredItem = useCallback(
    (hoveredItem: HoveredInfo | null) => {
      setEditingState({ ...editingState, hoveredItem })
    },
    [setEditingState, editingState]
  )

  // Extract current values from editingState
  const {
    editingField,
    editingRow,
    editingOption,
    editingCondition,
    hoveredItem,
    currentView,
    categoryStates
  } = editingState

  const handleRemoveField = useCallback(
    ({ rowIndex, fieldIndex }: { rowIndex: number; fieldIndex: number }) => {
      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        const fields = [...(rows[rowIndex].fields ?? [])].filter((_, i) => i !== fieldIndex)
        rows[rowIndex] = { ...rows[rowIndex], fields }
        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [setSelectedCollection]
  )

  const handleChangeFieldPath = useCallback(
    (rowIndex: number, fieldIndex: number, path: string) => {
      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        const fields = [...(rows[rowIndex].fields ?? [])]
        const field = { ...fields[fieldIndex], path } as ILayoutField
        fields[fieldIndex] = field
        rows[rowIndex] = { ...rows[rowIndex], fields }
        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [setSelectedCollection]
  )

  const handleChangeFieldComponent = useCallback(
    (rowIndex: number, fieldIndex: number, component: FieldComponentType) => {
      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        const fields = [...(rows[rowIndex].fields ?? [])]
        const field = { ...fields[fieldIndex], component } as ILayoutField
        fields[fieldIndex] = field
        rows[rowIndex] = { ...rows[rowIndex], fields }
        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [setSelectedCollection]
  )

  const fieldPathOptions = useMemo<string[]>(() => {
    if (!selectedCollection.uiSchema) return []
    const paths = new Set<string>()
    selectedCollection.uiSchema.rows.forEach((row) => {
      row.fields?.forEach((f) => paths.add(String(f.path)))
    })
    return Array.from(paths)
  }, [selectedCollection.uiSchema])

  // Context path options extracted from uiSchema.context
  const contextPathOptions = useMemo<string[]>(() => {
    if (!selectedCollection.uiSchema?.context) return []

    const extractPaths = (obj: Record<string, unknown>, prefix = ''): string[] => {
      const paths: string[] = []

      Object.keys(obj).forEach((key) => {
        const currentPath = prefix ? `${prefix}.${key}` : key
        const value = obj[key]

        // Add the current path
        paths.push(currentPath)

        // If the value is an object (but not null or array), recursively extract paths
        if (value && typeof value === 'object' && !Array.isArray(value)) {
          paths.push(...extractPaths(value as Record<string, unknown>, currentPath))
        }
      })

      return paths
    }

    return extractPaths(selectedCollection.uiSchema.context)
  }, [selectedCollection.uiSchema?.context])

  const handleAddField = useCallback(
    ({ rowIndex }: { rowIndex: number }) => {
      if (!selectedCollection.uiSchema) return

      const defaultPath = fieldPathOptions?.[0] ?? 'newField'

      const newField = {
        _id: uuidv4(),
        path: defaultPath as unknown as keyof UnknownRecord,
        label: DND_CARD_BUILDER_LABELS.NEW_FIELD_LABEL,
        component: FieldComponentType.inputText,
        placeholder: DND_CARD_BUILDER_LABELS.NEW_FIELD_PLACEHOLDER,
        width: WidthKey.W12
      } as unknown as ILayoutField

      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        const currentFields = rows[rowIndex]?.fields ?? []
        const newFieldIndex = currentFields.length // Index of the new field (last position)
        const row = {
          ...(rows[rowIndex] ?? { fields: [] }),
          fields: [...currentFields, newField]
        } as IFieldRow
        rows[rowIndex] = row

        // Navigate to the newly created field
        setTimeout(() => {
          setEditingState({
            ...editingState,
            currentView: ViewType.EditField,
            editingField: { rowIndex, fieldIndex: newFieldIndex }
          })
        }, 0)

        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [
      setSelectedCollection,
      fieldPathOptions,
      selectedCollection.uiSchema,
      setEditingState,
      editingState
    ]
  )

  const handleRowTitleChange = useCallback(
    (rowIndex: number, title: string) => {
      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        rows[rowIndex] = { ...rows[rowIndex], title }
        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [setSelectedCollection]
  )

  const handleRemoveRow = useCallback(
    (rowIndex: number) => {
      setHoveredItem(null)

      setSelectedCollection((prev) => {
        const rows = [...prev.uiSchema.rows]
        rows.splice(rowIndex, 1)
        return { ...prev, uiSchema: { ...prev.uiSchema, rows } }
      })
    },
    [setSelectedCollection, setHoveredItem]
  )

  const handleAddRow = useCallback(() => {
    setSelectedCollection((prev) => {
      const newRows = [
        ...prev.uiSchema.rows,
        { _id: uuidv4(), title: DND_CARD_BUILDER_LABELS.NEW_ROW_LABEL, fields: [] }
      ]

      // Navigate to the newly created row (last index)
      const newRowIndex = newRows.length - 1
      setTimeout(() => {
        setEditingState({
          ...editingState,
          currentView: ViewType.EditRow,
          editingRow: { rowIndex: newRowIndex }
        })
      }, 0)

      return { ...prev, uiSchema: { ...prev.uiSchema, rows: newRows } }
    })
  }, [setSelectedCollection, setEditingState, editingState])

  const navigateToEditRow = useCallback(
    (editingRow: EditingRowInfo) => {
      setHoveredItem(null)
      setEditingState({ ...editingState, currentView: ViewType.EditRow, editingRow })
    },
    [setHoveredItem, setEditingState, editingState]
  )

  const navigateToEditField = useCallback(
    (editingField: EditingFieldInfo) => {
      setHoveredItem(null)
      setEditingState({ ...editingState, currentView: ViewType.EditField, editingField })
    },
    [setHoveredItem, setEditingState, editingState]
  )

  const navigateBackToRows = useCallback(() => {
    setHoveredItem(null)
    setEditingState({
      ...editingState,
      currentView: ViewType.Rows,
      editingField: null,
      editingRow: null,
      hoveredItem: null,
      categoryStates: {
        ...editingState.categoryStates,
        row: initialCategoryStates.row,
        field: initialCategoryStates.field
      }
    })
  }, [setHoveredItem, setEditingState, editingState])

  const navigateBackToRow = useCallback(() => {
    setEditingState({
      ...editingState,
      hoveredItem: null,
      editingField: null,
      currentView: ViewType.EditRow,
      categoryStates: { ...editingState.categoryStates, field: initialCategoryStates.field }
    })
  }, [setEditingState, editingState])

  const navigateToEditOption = useCallback(
    (editingOption: EditingOptionInfo) => {
      setEditingState({
        ...editingState,
        hoveredItem: null,
        currentView: ViewType.EditOption,
        editingRow: { rowIndex: editingOption.rowIndex },
        editingField: { rowIndex: editingOption.rowIndex, fieldIndex: editingOption.fieldIndex },
        editingOption
      })
    },
    [setEditingState, editingState]
  )

  const navigateToEditCondition = useCallback(
    (editingCondition: EditingConditionInfo) => {
      if (typeof editingCondition.fieldIndex === 'number') {
        const newState = {
          ...editingState,
          hoveredItem: null,
          currentView: ViewType.EditCondition,
          editingRow: { rowIndex: editingCondition.rowIndex },
          editingField: {
            rowIndex: editingCondition.rowIndex,
            fieldIndex: editingCondition.fieldIndex
          },
          editingCondition
        }

        // If editing option-level condition, also set editingOption
        if (typeof editingCondition.optionIndex === 'number') {
          newState.editingOption = {
            rowIndex: editingCondition.rowIndex,
            fieldIndex: editingCondition.fieldIndex,
            optionIndex: editingCondition.optionIndex
          }
        }

        setEditingState(newState)
      } else {
        // Row-level condition
        setEditingState({
          ...editingState,
          hoveredItem: null,
          currentView: ViewType.EditCondition,
          editingRow: { rowIndex: editingCondition.rowIndex },
          editingCondition
        })
      }
    },
    [setEditingState, editingState]
  )

  const navigateBackToField = useCallback(() => {
    setEditingState({
      ...editingState,
      hoveredItem: null,
      editingOption: null,
      editingCondition: null,
      currentView: ViewType.EditField,
      categoryStates: { ...editingState.categoryStates, option: initialCategoryStates.option }
    })
  }, [setEditingState, editingState])

  const navigateBackToOption = useCallback(() => {
    setEditingState({
      ...editingState,
      hoveredItem: null,
      editingCondition: null,
      currentView: ViewType.EditOption
    })
  }, [setEditingState, editingState])

  const navigateBackToCondition = useCallback(
    (indexes: number[]) => {
      if (!editingCondition) {
        setEditingState({ ...editingState, currentView: ViewType.Rows })
        return
      }

      setEditingState({
        ...editingState,
        hoveredItem: null,
        currentView: ViewType.EditCondition,
        editingCondition: {
          ...editingCondition,
          conditionIndexes: indexes
        }
      })
    },
    [editingCondition, setEditingState, editingState]
  )

  const navigateBackFromCondition = useCallback(() => {
    if (!editingCondition) {
      setEditingState({ ...editingState, hoveredItem: null, currentView: ViewType.Rows })
      return
    }

    if (editingCondition.conditionIndexes?.length) {
      setEditingState({
        ...editingState,
        hoveredItem: null,
        editingCondition: {
          ...editingCondition,
          conditionIndexes: editingCondition.conditionIndexes.slice(0, -1)
        }
      })
    } else {
      // Navigate back to the appropriate view based on what we were editing
      let targetView = ViewType.EditRow

      if (typeof editingCondition.fieldIndex === 'number') {
        if (typeof editingCondition.optionIndex === 'number') {
          // Was editing option-level condition, go back to option
          targetView = ViewType.EditOption
        } else {
          // Was editing field-level condition, go back to field
          targetView = ViewType.EditField
        }
      }

      setEditingState({
        ...editingState,
        hoveredItem: null,
        editingCondition: null,
        currentView: targetView
      })
    }
  }, [editingCondition, setEditingState, editingState])

  // Category state management methods
  const updateFieldCategory = useCallback(
    (category: CategoryType) => {
      setEditingState({
        ...editingState,
        categoryStates: { ...editingState.categoryStates, field: category }
      })
    },
    [setEditingState, editingState]
  )

  const updateRowCategory = useCallback(
    (category: RowCategoryType) => {
      setEditingState({
        ...editingState,
        categoryStates: { ...editingState.categoryStates, row: category }
      })
    },
    [setEditingState, editingState]
  )

  const updateRowsCategory = useCallback(
    (category: RowsCategoryType) => {
      setEditingState({
        ...editingState,
        categoryStates: { ...editingState.categoryStates, rows: category }
      })
    },
    [setEditingState, editingState]
  )

  const updateOptionCategory = useCallback(
    (category: OptionCategoryType) => {
      setEditingState({
        ...editingState,
        categoryStates: { ...editingState.categoryStates, option: category }
      })
    },
    [setEditingState, editingState]
  )

  // Generic category state setter
  const setCategoryState = useCallback(
    (
      categoryType: 'field' | 'row' | 'rows' | 'option' | 'condition',
      category: CategoryType | RowCategoryType | RowsCategoryType | OptionCategoryType
    ) => {
      setEditingState({
        ...editingState,
        categoryStates: { ...editingState.categoryStates, [categoryType]: category }
      })
    },
    [setEditingState, editingState]
  )

  return useMemo(
    () => ({
      fieldPathOptions,
      contextPathOptions,
      handleChangeFieldPath,
      handleChangeFieldComponent,
      handleRemoveField,
      handleAddField,
      handleRowTitleChange,
      handleRemoveRow,
      handleAddRow,
      setSelectedCollection,
      selectedCollection,
      // View navigation
      currentView,
      editingField,
      editingRow,
      editingOption,
      editingCondition,
      hoveredItem,
      setHoveredItem,
      navigateToEditRow,
      navigateToEditField,
      navigateToEditOption,
      navigateToEditCondition,
      navigateBackToRows,
      navigateBackToRow,
      navigateBackToField,
      navigateBackToOption,
      navigateBackFromCondition,
      navigateBackToCondition,
      // Category state
      categoryStates,
      setCategoryState,
      updateFieldCategory,
      updateRowCategory,
      updateRowsCategory,
      updateOptionCategory
    }),
    [
      fieldPathOptions,
      contextPathOptions,
      handleChangeFieldPath,
      handleChangeFieldComponent,
      handleRemoveField,
      handleAddField,
      handleRowTitleChange,
      handleRemoveRow,
      handleAddRow,
      setSelectedCollection,
      selectedCollection,
      currentView,
      editingField,
      editingRow,
      editingOption,
      editingCondition,
      hoveredItem,
      setHoveredItem,
      navigateToEditRow,
      navigateToEditField,
      navigateToEditOption,
      navigateToEditCondition,
      navigateBackToRows,
      navigateBackToRow,
      navigateBackToField,
      navigateBackToOption,
      navigateBackFromCondition,
      navigateBackToCondition,
      categoryStates,
      setCategoryState,
      updateFieldCategory,
      updateRowCategory,
      updateRowsCategory,
      updateOptionCategory
    ]
  )
}
