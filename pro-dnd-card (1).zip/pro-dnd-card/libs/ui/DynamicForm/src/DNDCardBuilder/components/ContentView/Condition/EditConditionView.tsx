import React, { useMemo } from 'react'
import { useDNDCardBuilderContext } from '../../../utils/context'
import EditConditionCategory from './EditConditionCategory'
import _get from 'lodash/get'
import _set from 'lodash/set'
import { ConditionGroup, SingleCondition } from '../../../../DynamicForm/types'
import { produce } from 'immer'

const EditConditionView: React.FC = () => {
  const { editingCondition } = useDNDCardBuilderContext()
  const { selectedCollection, setSelectedCollection } = useDNDCardBuilderContext()

  const conditionPath = useMemo(() => {
    const { rowIndex, fieldIndex, optionIndex, conditionField, conditionIndexes } =
      editingCondition || {
        rowIndex: -1,
        fieldIndex: -1,
        optionIndex: undefined,
        conditionField: ''
      }

    const indexesPaths = conditionIndexes?.map((index) => ['conditions', `${index}`]).flat() ?? []

    if (typeof fieldIndex === 'number') {
      // Option-level condition
      if (typeof optionIndex === 'number') {
        return [
          rowIndex,
          'fields',
          fieldIndex,
          'options',
          'values',
          optionIndex,
          conditionField,
          ...indexesPaths
        ] as const
      }
      // Field-level condition
      return [rowIndex, 'fields', fieldIndex, conditionField, ...indexesPaths] as const
    }

    // Row-level condition
    return [rowIndex, conditionField, ...indexesPaths] as const
  }, [editingCondition])

  const condition = useMemo(
    () => _get(selectedCollection.uiSchema.rows, conditionPath) as ConditionGroup | SingleCondition,
    [selectedCollection.uiSchema.rows, conditionPath]
  )

  const updateCondition = (newCondition: ConditionGroup | SingleCondition) => {
    setSelectedCollection((prev) => {
      return produce(prev, (draft) => {
        _set(draft.uiSchema.rows, conditionPath, newCondition)
      })
    })
  }

  return <EditConditionCategory condition={condition} onChange={updateCondition} />
}

export default EditConditionView
