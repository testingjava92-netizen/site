import React, { useState, useEffect, useRef } from 'react'
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Alert,
  Box,
  IconButton,
  Tooltip,
  TextField,
  InputAdornment,
  Divider
} from '@mui/material'
import ContentCopyIcon from '@mui/icons-material/ContentCopy'
import CheckIcon from '@mui/icons-material/Check'
import SearchIcon from '@mui/icons-material/Search'
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'
import CloseIcon from '@mui/icons-material/Close'
import { create, InstanceProps } from 'react-modal-promise'
import { DND_CARD_BUILDER_LABELS } from '../../constants'
import { ICardSchemaMeta } from '../../../DynamicForm/types'
import HighlightedJsonEditor from './HighlightedJsonEditor'

export interface UiSchemaEditorDialogProps extends InstanceProps<ICardSchemaMeta | null> {
  uiSchema: ICardSchemaMeta
}

const UiSchemaEditorDialog: React.FC<UiSchemaEditorDialogProps> = ({
  isOpen,
  onReject,
  onResolve,
  uiSchema
}) => {
  const [jsonString, setJsonString] = useState('')
  const [error, setError] = useState('')
  const [isValid, setIsValid] = useState(true)
  const [isCopied, setIsCopied] = useState(false)

  // Search functionality state
  const [searchTerm, setSearchTerm] = useState('')
  const [showSearch, setShowSearch] = useState(false)
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0)
  const [totalMatches, setTotalMatches] = useState(0)
  const [searchMatches, setSearchMatches] = useState<{ start: number; end: number }[]>([])

  const editorRef = useRef<{ focusOnMatch: (index: number) => void } | null>(null)

  useEffect(() => {
    if (uiSchema) {
      setJsonString(JSON.stringify(uiSchema, null, 2))
    }
  }, [uiSchema])

  const validateAndParseJson = (json: string) => {
    try {
      const parsed = JSON.parse(json)

      // Basic validation for UI schema structure
      if (!parsed || typeof parsed !== 'object') {
        throw new Error('UI Schema must be an object')
      }

      if (!parsed.rows || !Array.isArray(parsed.rows)) {
        throw new Error('UI Schema must have a rows array')
      }

      setError('')
      setIsValid(true)
      return parsed as ICardSchemaMeta
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Invalid JSON format'
      setError(errorMessage)
      setIsValid(false)
      return null
    }
  }

  const handleJsonChange = (value: string) => {
    setJsonString(value)

    if (value.trim()) {
      validateAndParseJson(value)
    } else {
      setError('')
      setIsValid(true)
    }
  }

  const handleApprove = () => {
    if (!jsonString.trim()) {
      setError('JSON content cannot be empty')
      setIsValid(false)
      return
    }

    const parsedSchema = validateAndParseJson(jsonString)
    if (parsedSchema && isValid) {
      onResolve(parsedSchema)
    }
  }

  const handleCancel = () => {
    onReject()
  }

  const formatJson = () => {
    try {
      const parsed = JSON.parse(jsonString)
      setJsonString(JSON.stringify(parsed, null, 2))
      setError('')
      setIsValid(true)
    } catch {
      // Keep the current content if it can't be parsed
    }
  }

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonString)
    setIsCopied(true)
    setTimeout(() => {
      setIsCopied(false)
    }, 2000)
  }

  // Search functionality
  const performSearch = (term: string) => {
    if (!term.trim()) {
      setSearchMatches([])
      setTotalMatches(0)
      setCurrentMatchIndex(0)
      return
    }

    const matches: { start: number; end: number }[] = []
    const searchRegex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi')
    let match

    while ((match = searchRegex.exec(jsonString)) !== null) {
      matches.push({
        start: match.index,
        end: match.index + match[0].length
      })
      // Prevent infinite loop for zero-length matches
      if (match[0].length === 0) break
    }

    setSearchMatches(matches)
    setTotalMatches(matches.length)
    setCurrentMatchIndex(matches.length > 0 ? 0 : -1)

    // Focus on first match if available
    if (matches.length > 0 && editorRef.current) {
      editorRef.current.focusOnMatch(0)
    }
  }

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newSearchTerm = event.target.value
    setSearchTerm(newSearchTerm)
    performSearch(newSearchTerm)
  }

  const handleSearchKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      event.preventDefault()
      navigateToNextMatch()
    }
  }

  const navigateToNextMatch = () => {
    if (totalMatches === 0) return

    const nextIndex = (currentMatchIndex + 1) % totalMatches
    setCurrentMatchIndex(nextIndex)

    if (editorRef.current) {
      editorRef.current.focusOnMatch(nextIndex)
    }
  }

  const navigateToPrevMatch = () => {
    if (totalMatches === 0) return

    const prevIndex = currentMatchIndex === 0 ? totalMatches - 1 : currentMatchIndex - 1
    setCurrentMatchIndex(prevIndex)

    if (editorRef.current) {
      editorRef.current.focusOnMatch(prevIndex)
    }
  }

  const toggleSearch = () => {
    setShowSearch(!showSearch)
    if (showSearch) {
      // Clear search when closing
      setSearchTerm('')
      setSearchMatches([])
      setTotalMatches(0)
      setCurrentMatchIndex(0)
    }
  }

  // Keyboard shortcuts
  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.ctrlKey && event.key === 'f') {
      event.preventDefault()
      setShowSearch(true)
    }
    if (event.key === 'Escape' && showSearch) {
      toggleSearch()
    }
  }

  return (
    <Dialog
      open={isOpen}
      onClose={handleCancel}
      onKeyDown={handleKeyDown}
      maxWidth='md'
      fullWidth
      PaperProps={{
        sx: { height: '80vh', display: 'flex', flexDirection: 'column' }
      }}
    >
      <DialogTitle>
        <Typography variant='h6'>עורך סכמת UI</Typography>
        <Typography variant='body2' color='text.secondary' sx={{ mt: 1 }}>
          ערוך את סכמת ה-UI בפורמט JSON
        </Typography>
      </DialogTitle>

      <DialogContent sx={{ display: 'flex', flexDirection: 'column', flex: 1, gap: 2 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant='subtitle2' color='text.secondary'>
            JSON Schema
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Tooltip title='חפש בתוך ה-JSON (Ctrl+F)'>
              <IconButton size='small' onClick={toggleSearch}>
                <SearchIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title={isCopied ? 'JSON הועתק' : 'העתק JSON ללוח'}>
              <IconButton size='small' onClick={handleCopyJson} disabled={!jsonString.trim()}>
                {isCopied ? <CheckIcon /> : <ContentCopyIcon />}
              </IconButton>
            </Tooltip>
            <Button
              size='small'
              variant='outlined'
              onClick={formatJson}
              disabled={!jsonString.trim()}
            >
              עיצוב JSON
            </Button>
          </Box>
        </Box>

        {/* Search Panel */}
        {showSearch && (
          <>
            <Box
              sx={{
                p: 2,
                bgcolor: 'background.default',
                borderRadius: 1,
                border: 1,
                borderColor: 'divider'
              }}
            >
              <TextField
                size='small'
                value={searchTerm}
                onChange={handleSearchChange}
                onKeyDown={handleSearchKeyDown}
                placeholder='חפש בתוך ה-JSON... (Enter לעבור למציאה הבאה)'
                variant='outlined'
                fullWidth
                autoFocus
                InputProps={{
                  startAdornment: (
                    <InputAdornment position='start'>
                      <SearchIcon fontSize='small' />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position='end'>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        {totalMatches > 0 && (
                          <Typography variant='caption' color='text.secondary' sx={{ mr: 1 }}>
                            {currentMatchIndex + 1}/{totalMatches}
                          </Typography>
                        )}
                        <Tooltip title='תוצאה קודמת'>
                          <IconButton
                            size='small'
                            onClick={navigateToPrevMatch}
                            disabled={totalMatches === 0}
                          >
                            <KeyboardArrowUpIcon fontSize='small' />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title='תוצאה הבאה'>
                          <IconButton
                            size='small'
                            onClick={navigateToNextMatch}
                            disabled={totalMatches === 0}
                          >
                            <KeyboardArrowDownIcon fontSize='small' />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title='סגור חיפוש'>
                          <IconButton size='small' onClick={toggleSearch}>
                            <CloseIcon fontSize='small' />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </InputAdornment>
                  )
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: 'primary.main'
                    }
                  }
                }}
              />
            </Box>
            <Divider />
          </>
        )}

        {error && (
          <Alert severity='error' sx={{ mb: 1 }}>
            {error}
          </Alert>
        )}

        <Box sx={{ flex: 1 }}>
          <HighlightedJsonEditor
            ref={editorRef}
            value={jsonString}
            onChange={handleJsonChange}
            placeholder='הזן את סכמת ה-UI בפורמט JSON...'
            error={!isValid}
            searchMatches={searchMatches}
            currentMatchIndex={currentMatchIndex}
          />
        </Box>

        <Typography variant='caption' color='text.secondary'>
          הסכמה חייבת לכלול מאפיין "layout" שהוא מערך של שורות
        </Typography>
      </DialogContent>

      <DialogActions sx={{ p: 3, pt: 2 }}>
        <Button onClick={handleCancel} color='inherit'>
          {DND_CARD_BUILDER_LABELS.CANCEL}
        </Button>
        <Button
          onClick={handleApprove}
          variant='contained'
          disabled={!isValid || !jsonString.trim()}
        >
          {DND_CARD_BUILDER_LABELS.SAVE}
        </Button>
      </DialogActions>
    </Dialog>
  )
}

export const openUiSchemaEditorDialog = create(UiSchemaEditorDialog)

export default UiSchemaEditorDialog
