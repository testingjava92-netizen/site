import React from 'react'
import { Stack, FormControlLabel, Switch, Typography } from '@mui/material'
import {
  FieldComponentType,
  IInputDateRangeLayoutField,
  DateRangeValidations
} from '../../../../../DynamicForm/types'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../../constants'
import DateRangeValidationPanel from '../../EditField/DateRangeValidationPanel'

interface ValidationCategoryProps {
  rowIndex: number
  fieldIndex: number
}

const ValidationCategory: React.FC<ValidationCategoryProps> = ({ rowIndex, fieldIndex }) => {
  const { setSelectedCollection, selectedCollection } = useDNDCardBuilderContext()

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[fieldIndex]

  const updateField = (updates: Record<string, unknown>) => {
    if (!field) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((row, index) =>
          index === rowIndex
            ? {
                ...row,
                fields: row.fields?.map((fieldItem) =>
                  fieldItem._id === field._id ? { ...fieldItem, ...updates } : fieldItem
                )
              }
            : row
        )
      }
    }))
  }

  if (!field) {
    return null
  }

  const isDateRange = field.component === FieldComponentType.inputDateRange

  return (
    <Stack spacing={3}>
      <FormControlLabel
        control={
          <Switch
            checked={Boolean((field as { required?: boolean }).required)}
            onChange={(e) => updateField({ required: e.target.checked })}
          />
        }
        label={DND_CARD_BUILDER_LABELS.FIELD_REQUIRED}
      />

      {isDateRange && (
        <DateRangeValidationPanel
          validations={(field as IInputDateRangeLayoutField).dateRangeValidations}
          onChange={(validations: DateRangeValidations) =>
            updateField({ dateRangeValidations: validations })
          }
        />
      )}
    </Stack>
  )
}

export default ValidationCategory
