import React, { useMemo } from 'react'
import { Switch, FormControlLabel, RadioGroup, Radio, Box, Button } from '@mui/material'
import { Condition, ConditionOperator, DefaultSchema } from '../../../../DynamicForm/types'
import { DND_CARD_BUILDER_LABELS, DEFAULT_SINGLE_CONDITION } from '../../../constants'

type BooleanOrConditionValue<Schema = DefaultSchema> = boolean | Condition<Schema>

interface BooleanOrConditionsManagerProps<Schema = DefaultSchema> {
  label: string
  value?: BooleanOrConditionValue<Schema>
  onChange: (value?: BooleanOrConditionValue<Schema>) => void
  availableFields: string[]
  onEditCondition?: () => void
}

const BooleanOrConditionsManager = <Schema extends DefaultSchema = DefaultSchema>({
  label,
  value,
  onChange,
  onEditCondition
}: BooleanOrConditionsManagerProps<Schema>) => {
  const isEnabled = value !== undefined

  const mode = useMemo(() => {
    if (value === true) {
      return 'always'
    } else {
      return 'conditional'
    }
  }, [value])

  const handleEnabledChange = (checked: boolean) => {
    if (!checked) {
      onChange(undefined)
    } else {
      onChange(true)
    }
  }

  const handleModeChange = (newMode: 'always' | 'conditional') => {
    if (newMode === 'always') {
      onChange(true)
    } else {
      onChange(DEFAULT_SINGLE_CONDITION)
    }
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <FormControlLabel
        control={
          <Switch checked={isEnabled} onChange={(e) => handleEnabledChange(e.target.checked)} />
        }
        label={label}
      />

      {isEnabled && (
        <Box sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
          <RadioGroup
            value={mode}
            onChange={(e) => handleModeChange(e.target.value as 'always' | 'conditional')}
            row
          >
            <FormControlLabel
              value='always'
              control={<Radio />}
              label={DND_CARD_BUILDER_LABELS.CONDITION_ALWAYS_MODE}
            />
            <FormControlLabel
              value='conditional'
              control={<Radio />}
              label={DND_CARD_BUILDER_LABELS.CONDITION_CONDITIONAL_MODE}
            />
          </RadioGroup>

          {mode === 'conditional' && (
            <Button variant='outlined' onClick={onEditCondition}>
              {DND_CARD_BUILDER_LABELS.EDIT_CONDITION}
            </Button>
          )}
        </Box>
      )}
    </Box>
  )
}

export default BooleanOrConditionsManager
