import React, { useMemo } from 'react'
import { Box, Breadcrumbs, Link } from '@mui/material'
import NavigateNextIcon from '@mui/icons-material/NavigateNext'
import { DND_CARD_BUILDER_LABELS } from '../constants'
import { useDNDCardBuilderContext } from '../utils/context'
import { ViewType } from '../types'
import { ConditionField, IFieldRow, ISelectLayoutField } from '../..'
import _get from 'lodash/get'
import { ConditionGroup, SingleCondition } from '../../DynamicForm/types'

interface BreadcrumbItem {
  label: string
  onClick?: () => void
}

const createRootBreadcrumb = ({ onClick }: { onClick: () => void }) => {
  return {
    label: DND_CARD_BUILDER_LABELS.BREADCRUMB_ROWS,
    onClick
  }
}

const createRowBreadcrumb = ({
  rows,
  rowIndex,
  onClick
}: {
  rows: IFieldRow[]
  rowIndex: number
  onClick: () => void
}) => {
  const row = rows[rowIndex]

  return {
    label: row?.title || `שורה ${rowIndex + 1}`,
    onClick
  }
}

const createFieldBreadcrumb = ({
  rows,
  rowIndex,
  fieldIndex,
  onClick
}: {
  rows: IFieldRow[]
  rowIndex: number
  fieldIndex: number
  onClick: () => void
}) => {
  const field = rows[rowIndex].fields[fieldIndex]
  return {
    label: field?.label || `שדה ${fieldIndex + 1}`,
    onClick
  }
}

const createOptionBreadcrumb = ({
  rows,
  rowIndex,
  fieldIndex,
  optionIndex,
  onClick
}: {
  rows: IFieldRow[]
  rowIndex: number
  fieldIndex: number
  optionIndex: number
  onClick: () => void
}) => {
  const field = rows[rowIndex].fields[fieldIndex] as ISelectLayoutField
  const option = field.options?.values?.[optionIndex]

  return {
    label: option?.label || `אפשרות ${optionIndex + 1}`,
    onClick
  }
}

const createConditionBreadcrumbs = ({
  conditionIndexes,
  conditionField,
  navigateBackToCondition,
  rows,
  rowIndex,
  fieldIndex,
  optionIndex
}: {
  conditionIndexes?: number[]
  conditionField: ConditionField
  navigateBackToCondition: (indexes: number[]) => void
  rows: IFieldRow[]
  rowIndex: number
  fieldIndex?: number
  optionIndex?: number
}) => {
  const parentConditions = [
    {
      label: conditionField === ConditionField.hidden ? 'תנאי להסתרה' : 'תנאי לניטרול',
      onClick: () => navigateBackToCondition([])
    }
  ]

  if (conditionIndexes?.length) {
    parentConditions.push(
      ...conditionIndexes.map((conditionIndex, index, array) => {
        // Build path to the specific condition
        const conditionPath = [...array.slice(0, index + 1)]
        const pathSegments = conditionPath.map((idx) => ['conditions', `${idx}`]).flat()

        let fullPath: (string | number)[]
        if (typeof fieldIndex === 'number') {
          if (typeof optionIndex === 'number') {
            // Option-level condition path
            fullPath = [
              rowIndex,
              'fields',
              fieldIndex,
              'options',
              'values',
              optionIndex,
              conditionField,
              ...pathSegments
            ]
          } else {
            // Field-level condition path
            fullPath = [rowIndex, 'fields', fieldIndex, conditionField, ...pathSegments]
          }
        } else {
          // Row-level condition path
          fullPath = [rowIndex, conditionField, ...pathSegments]
        }

        const condition = _get(rows, fullPath) as ConditionGroup | SingleCondition | undefined
        const conditionTitle = condition?.title

        const defaultLabel = `תנאי ${conditionIndex + 1}`
        const label = conditionTitle ? `${defaultLabel}: ${conditionTitle}` : defaultLabel

        return {
          label,
          onClick: () => navigateBackToCondition(conditionPath)
        }
      })
    )
  }

  return parentConditions
}

const useBreadcrumbs = (): BreadcrumbItem[] => {
  const {
    editingField,
    editingRow,
    editingOption,
    editingCondition,
    currentView,
    selectedCollection,
    navigateBackToRows,
    navigateBackToRow,
    navigateBackToField,
    navigateBackToOption,
    navigateBackToCondition
  } = useDNDCardBuilderContext()

  return useMemo(() => {
    const rows = selectedCollection.uiSchema.rows

    const root: BreadcrumbItem[] = [createRootBreadcrumb({ onClick: navigateBackToRows })]

    switch (currentView) {
      case ViewType.EditRow: {
        if (!editingRow) {
          return root
        }
        const { rowIndex } = editingRow

        return [...root, createRowBreadcrumb({ rows, rowIndex, onClick: navigateBackToRow })]
      }

      case ViewType.EditField: {
        if (!editingField) {
          return root
        }

        const { rowIndex, fieldIndex } = editingField

        return [
          ...root,
          createRowBreadcrumb({ rows, rowIndex, onClick: navigateBackToRow }),
          createFieldBreadcrumb({ rows, rowIndex, fieldIndex, onClick: navigateBackToField })
        ]
      }

      case ViewType.EditOption: {
        if (!editingOption) {
          return root
        }

        const { rowIndex, fieldIndex, optionIndex } = editingOption

        return [
          ...root,
          createRowBreadcrumb({ rows, rowIndex, onClick: navigateBackToRow }),
          createFieldBreadcrumb({ rows, rowIndex, fieldIndex, onClick: navigateBackToField }),
          createOptionBreadcrumb({
            rows,
            rowIndex,
            fieldIndex,
            optionIndex,
            onClick: navigateBackToOption
          })
        ]
      }

      case ViewType.EditCondition: {
        if (!editingCondition) {
          return root
        }

        const { rowIndex, fieldIndex, optionIndex, conditionIndexes, conditionField } =
          editingCondition

        const base = [...root, createRowBreadcrumb({ rows, rowIndex, onClick: navigateBackToRow })]

        if (typeof fieldIndex === 'number') {
          base.push(
            createFieldBreadcrumb({ rows, rowIndex, fieldIndex, onClick: navigateBackToField })
          )

          // Add option breadcrumb if editing option-level condition
          if (typeof optionIndex === 'number') {
            base.push(
              createOptionBreadcrumb({
                rows,
                rowIndex,
                fieldIndex,
                optionIndex,
                onClick: navigateBackToOption
              })
            )
          }
        }

        return [
          ...base,
          ...createConditionBreadcrumbs({
            conditionIndexes,
            conditionField,
            navigateBackToCondition,
            rows,
            rowIndex,
            fieldIndex,
            optionIndex
          })
        ]
      }
    }

    return root
  }, [
    currentView,
    selectedCollection,
    editingRow,
    editingField,
    editingOption,
    editingCondition,
    navigateBackToRows,
    navigateBackToRow,
    navigateBackToField,
    navigateBackToOption,
    navigateBackToCondition
  ])
}

const BreadcrumbsBar: React.FC = () => {
  const breadcrumbs = useBreadcrumbs()

  return (
    <Box
      sx={{
        px: 2,
        py: 1.5,
        borderBottom: (theme) => `1px solid ${theme.palette.divider}`
      }}
    >
      <Breadcrumbs separator={<NavigateNextIcon fontSize='small' />} sx={{ fontSize: '0.875rem' }}>
        {breadcrumbs.map((breadcrumb, index) => (
          <Link
            key={index}
            color='inherit'
            sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
            onClick={breadcrumb.onClick}
          >
            {breadcrumb.label}
          </Link>
        ))}
      </Breadcrumbs>
    </Box>
  )
}

export default BreadcrumbsBar
