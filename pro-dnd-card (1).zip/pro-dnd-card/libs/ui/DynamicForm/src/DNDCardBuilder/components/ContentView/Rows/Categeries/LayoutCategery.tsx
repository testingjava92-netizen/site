import { Stack } from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { GapKey, SizeKey } from '../../../../../DynamicForm/types'
import AutoManualSlider from '../../../AutoManualSlider'
import { DEFAULT_GAP, DEFAULT_PX, DEFAULT_PY, DEFAULT_ROW_HEIGHT } from '../../../../constants'
import { heightMap } from '../../../../../DynamicForm/constants'

const LayoutCategery = () => {
  const { selectedCollection, setSelectedCollection } = useDNDCardBuilderContext()

  const handleGapChange = (value: number | undefined) => {
    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: { ...prev.uiSchema, gap: value as GapKey | undefined }
    }))
  }

  const handlePxChange = (value: number | undefined) => {
    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: { ...prev.uiSchema, px: value as SizeKey | undefined }
    }))
  }

  const handlePyChange = (value: number | undefined) => {
    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: { ...prev.uiSchema, py: value as SizeKey | undefined }
    }))
  }

  const handleRowHeightChange = (value: number | undefined) => {
    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: { ...prev.uiSchema, rowHeight: value as SizeKey | undefined }
    }))
  }

  return (
    <Stack spacing={5}>
      <AutoManualSlider
        label='רווח בין שורות'
        value={selectedCollection.uiSchema.gap}
        initialValue={DEFAULT_GAP}
        onChange={handleGapChange}
        min={0}
        max={20}
        valueLabelFormat={(value: number) => {
          const gapInPx = value * 8
          return `S${value} (${gapInPx}px)`
        }}
        displayFormat={(value: number) => `רווח נוכחי: S${value} (${value * 8}px)`}
      />

      <AutoManualSlider
        label='ריפוד אופקי (שמאל/ימין)'
        value={selectedCollection.uiSchema.px}
        initialValue={DEFAULT_PX}
        onChange={handlePxChange}
        min={0}
        max={20}
        valueLabelFormat={(value: number) => {
          const pxInPx = value * 8
          return `S${value} (${pxInPx}px)`
        }}
        displayFormat={(value: number) => `ריפוד נוכחי: S${value} (${value * 8}px)`}
      />

      <AutoManualSlider
        label='ריפוד אנכי (עליון/תחתון)'
        value={selectedCollection.uiSchema.py}
        initialValue={DEFAULT_PY}
        onChange={handlePyChange}
        min={0}
        max={20}
        valueLabelFormat={(value: number) => {
          const pyInPx = value * 8
          return `S${value} (${pyInPx}px)`
        }}
        displayFormat={(value: number) => `ריפוד נוכחי: S${value} (${value * 8}px)`}
      />

      <AutoManualSlider
        label='גובה שורה'
        value={selectedCollection.uiSchema.rowHeight}
        initialValue={DEFAULT_ROW_HEIGHT}
        onChange={handleRowHeightChange}
        min={0}
        max={20}
        valueLabelFormat={(value: number) => heightMap[value as SizeKey]}
        displayFormat={(value: number) => `גובה נוכחי: S${value} (${heightMap[value as SizeKey]})`}
      />
    </Stack>
  )
}

export default LayoutCategery
