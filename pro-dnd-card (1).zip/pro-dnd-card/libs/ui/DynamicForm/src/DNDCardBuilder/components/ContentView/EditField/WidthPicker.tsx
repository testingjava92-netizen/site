import React, { useState, useEffect } from 'react'
import { Box, TextField, FormControl, Stack, Typography } from '@mui/material'
import { WidthKey } from '../../../../DynamicForm/types'
import { DND_CARD_BUILDER_LABELS } from '../../../constants'
import AutoManualSlider from '../../AutoManualSlider'
import { DEFAULT_WIDTH } from '../../../../DNDCardBuilder/constants'

export interface WidthPickerProps {
  value?: WidthKey
  onChange: (width: WidthKey | undefined) => void
  label?: string
}

const WidthPicker: React.FC<WidthPickerProps> = ({
  value,
  onChange,
  label = DND_CARD_BUILDER_LABELS.FIELD_WIDTH_DEFAULT
}) => {
  const [sliderValue, setSliderValue] = useState<number>(value || 12)

  // Update internal state when value prop changes
  useEffect(() => {
    setSliderValue(value || 12)
  }, [value])

  const handleChange = (newValue: number | undefined) => {
    onChange(newValue as WidthKey | undefined)
    if (newValue !== undefined) {
      setSliderValue(newValue)
    }
  }

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value
    const numValue = parseInt(inputValue, 10)

    if (inputValue === '' || (numValue >= 1 && numValue <= 12)) {
      const finalValue = inputValue === '' ? 12 : numValue
      setSliderValue(finalValue)
      if (value !== undefined) {
        onChange(finalValue as WidthKey)
      }
    }
  }

  return (
    <FormControl fullWidth>
      <Stack spacing={2}>
        <AutoManualSlider
          label={label}
          value={value}
          onChange={handleChange}
          min={1}
          max={12}
          initialValue={DEFAULT_WIDTH}
          valueLabelFormat={(val: number) => `${val}/12`}
          displayFormat={(val: number) => DND_CARD_BUILDER_LABELS.COLUMNS_WIDTH_FORMAT(val)}
          sliderProps={{
            marks: [
              { value: 1, label: '1' },
              { value: 3, label: '3' },
              { value: 6, label: '6' },
              { value: 9, label: '9' },
              { value: 12, label: '12' }
            ],
            track: 'normal'
          }}
        />
      </Stack>
    </FormControl>
  )
}

export default WidthPicker
