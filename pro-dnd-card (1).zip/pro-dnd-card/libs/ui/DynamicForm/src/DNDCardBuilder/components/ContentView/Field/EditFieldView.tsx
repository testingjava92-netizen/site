import React from 'react'
import SettingsIcon from '@mui/icons-material/Settings'
import LayoutIcon from '@mui/icons-material/ViewQuilt'
import ValidateIcon from '@mui/icons-material/VerifiedUser'
import TextFieldsIcon from '@mui/icons-material/TextFields'
import ListIcon from '@mui/icons-material/List'
import TuneIcon from '@mui/icons-material/Tune'
import { FieldComponentType } from '../../../../DynamicForm/types'
import { useDNDCardBuilderContext } from '../../../utils/context'
import { DND_CARD_BUILDER_LABELS } from '../../../constants'
import MenuList, { MenuCategory } from '../MenuList'
import EditFieldCategory from './EditFieldCategory'
import { CategoryType } from '../../../types'

const categories: MenuCategory[] = [
  { id: 'basic', label: 'בסיסי', icon: <SettingsIcon /> },
  { id: 'layout', label: 'פריסה', icon: <LayoutIcon /> },
  { id: 'validation', label: 'ולידציה', icon: <ValidateIcon /> },
  { id: 'input', label: 'קלט', icon: <TextFieldsIcon /> },
  { id: 'options', label: DND_CARD_BUILDER_LABELS.SELECT_PROPERTIES_SECTION, icon: <ListIcon /> },
  { id: 'advanced', label: 'מתקדם', icon: <TuneIcon /> }
]

const EditFieldView: React.FC = () => {
  const { selectedCollection, categoryStates, updateFieldCategory, editingField } =
    useDNDCardBuilderContext()

  const selectedCategory = categoryStates.field

  const field =
    selectedCollection.uiSchema.rows?.[editingField?.rowIndex ?? -1]?.fields?.[
      editingField?.fieldIndex ?? -1
    ]

  if (!field) {
    return null
  }

  const getAvailableCategories = (): CategoryType[] => {
    const baseCategories: CategoryType[] = [
      CategoryType.Basic,
      CategoryType.Layout,
      CategoryType.Validation
    ]

    if (
      [
        FieldComponentType.inputText,
        FieldComponentType.inputNumber,
        FieldComponentType.inputEmail,
        FieldComponentType.inputPassword,
        FieldComponentType.textarea,
        FieldComponentType.inputDateTime,
        FieldComponentType.inputDateRange,
        FieldComponentType.inputSlider
      ].includes(field.component)
    ) {
      baseCategories.push(CategoryType.Input)
    }

    // Add options category for select-based fields
    if (
      [
        FieldComponentType.select,
        FieldComponentType.buttonsGroup,
        FieldComponentType.chipsSelect,
        FieldComponentType.inputRadio
      ].includes(field.component)
    ) {
      baseCategories.push(CategoryType.Options)
    }

    baseCategories.push(CategoryType.Advanced)
    return baseCategories
  }

  const availableCategories = getAvailableCategories()

  return (
    <>
      <MenuList
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={(categoryId) => updateFieldCategory(categoryId as CategoryType)}
        availableCategories={availableCategories}
      />

      <EditFieldCategory
        selectedCategory={selectedCategory}
        rowIndex={editingField?.rowIndex ?? -1}
        fieldIndex={editingField?.fieldIndex ?? -1}
      />
    </>
  )
}

export default EditFieldView
