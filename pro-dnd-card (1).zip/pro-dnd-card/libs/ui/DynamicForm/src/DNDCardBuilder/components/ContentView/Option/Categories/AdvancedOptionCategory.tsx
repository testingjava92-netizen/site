import React, { useState, useEffect } from 'react'
import { Stack, Divider } from '@mui/material'
import { useDNDCardBuilderContext } from '../../../../utils/context'
import { ISelectLayoutField, IOption } from '../../../../../DynamicForm/types'
import { ConditionField } from '../../../../../DynamicForm/types/enums'
import BooleanOrConditionsManager from '../../Condition/BooleanOrConditionsManager'

interface AdvancedOptionCategoryProps {
  rowIndex: number
  fieldIndex: number
  optionIndex: number
}

const AdvancedOptionCategory: React.FC<AdvancedOptionCategoryProps> = ({
  rowIndex,
  fieldIndex,
  optionIndex
}) => {
  const { setSelectedCollection, selectedCollection, fieldPathOptions, navigateToEditCondition } =
    useDNDCardBuilderContext()

  const field = selectedCollection.uiSchema.rows?.[rowIndex]?.fields?.[
    fieldIndex
  ] as ISelectLayoutField
  const option = field?.options?.values?.[optionIndex] as IOption

  const [localOption, setLocalOption] = useState<IOption>(option)

  // Update local state when option prop changes
  useEffect(() => {
    setLocalOption(option)
  }, [option])

  const updateOption = (updatedOption: IOption) => {
    if (!field) return

    setSelectedCollection((prev) => ({
      ...prev,
      uiSchema: {
        ...prev.uiSchema,
        rows: prev.uiSchema.rows.map((row, index) =>
          index === rowIndex
            ? {
                ...row,
                fields: row.fields?.map((fieldItem) =>
                  fieldItem._id === field._id
                    ? {
                        ...fieldItem,
                        options: {
                          ...((fieldItem as ISelectLayoutField).options || {}),
                          values: ((fieldItem as ISelectLayoutField).options?.values || []).map(
                            (opt, idx) => (idx === optionIndex ? updatedOption : opt)
                          )
                        }
                      }
                    : fieldItem
                )
              }
            : row
        )
      }
    }))
  }

  // Handle changes and propagate to parent
  const handleChange = (updatedOption: IOption) => {
    setLocalOption(updatedOption)
    updateOption(updatedOption)
  }

  if (!localOption) {
    return null
  }

  return (
    <Stack spacing={3}>
      {/* Hidden Condition */}
      <BooleanOrConditionsManager
        label='אפשרות מוסתרת'
        value={localOption.hidden}
        onChange={(value) => handleChange({ ...localOption, hidden: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              fieldIndex,
              optionIndex,
              conditionField: ConditionField.hidden
            })
          }
        }}
      />

      <Divider />

      {/* Disabled Condition */}
      <BooleanOrConditionsManager
        label='אפשרות מנוטרלת'
        value={localOption.disabled}
        onChange={(value) => handleChange({ ...localOption, disabled: value })}
        availableFields={fieldPathOptions}
        onEditCondition={() => {
          if (navigateToEditCondition) {
            navigateToEditCondition({
              rowIndex,
              fieldIndex,
              optionIndex,
              conditionField: ConditionField.disabled
            })
          }
        }}
      />
    </Stack>
  )
}

export default AdvancedOptionCategory
