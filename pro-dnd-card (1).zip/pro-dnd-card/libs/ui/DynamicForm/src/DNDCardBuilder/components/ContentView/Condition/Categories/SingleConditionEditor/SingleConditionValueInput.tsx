import {
  Box,
  Button,
  ButtonGroup,
  FormControlLabel,
  Switch,
  TextField,
  Typography
} from '@mui/material'
import { ConditionValue, DefaultSchema, SingleCondition } from '../../../../../../DynamicForm/types'

type ValueType = 'string' | 'number' | 'boolean'

interface SingleConditionValueInputProps<Schema = DefaultSchema> {
  condition: SingleCondition<Schema>
  valueType: ValueType
  canChooseValueType: boolean
  needsValueInput: boolean
  onValueTypeChange: (newType: ValueType) => void
  onValueChange: (value: ConditionValue) => void
}

const SingleConditionValueInput = <Schema extends DefaultSchema = DefaultSchema>({
  condition,
  valueType,
  canChooseValueType,
  needsValueInput,
  onValueTypeChange,
  onValueChange
}: SingleConditionValueInputProps<Schema>) => {
  if (!needsValueInput) {
    return null
  }

  const renderInput = () => {
    switch (valueType) {
      case 'boolean':
        return (
          <FormControlLabel
            control={
              <Switch
                checked={Boolean(condition.value)}
                onChange={(e) => onValueChange(e.target.checked)}
              />
            }
            label={condition.value ? 'אמת' : 'שקר'}
          />
        )
      case 'number':
        return (
          <TextField
            label='ערך מספרי'
            value={condition.value ?? ''}
            onChange={(e) => {
              const value = e.target.value
              if (value === '') {
                onValueChange('')
              } else {
                const numericValue = Number(value)
                if (!isNaN(numericValue)) {
                  onValueChange(numericValue)
                } else {
                  // Keep the string value for partial input (e.g., "3.", "-", etc.)
                  onValueChange(value)
                }
              }
            }}
            onBlur={(e) => {
              // On blur, ensure we have a valid number or empty string
              const value = e.target.value
              if (value === '') {
                onValueChange('')
              } else {
                const numericValue = parseFloat(value)
                onValueChange(isNaN(numericValue) ? 0 : numericValue)
              }
            }}
            type='number'
            fullWidth
            placeholder='הכנס מספר'
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'background.default'
              }
            }}
          />
        )
      case 'string':
      default:
        return (
          <TextField
            label='ערך טקסט'
            value={condition.value ?? ''}
            onChange={(e) => onValueChange(e.target.value)}
            type='text'
            fullWidth
            placeholder='הכנס ערך'
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'background.default'
              }
            }}
          />
        )
    }
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {canChooseValueType && (
        <Box sx={{ mb: 2 }}>
          <Typography variant='caption' sx={{ mb: 1, display: 'block', fontWeight: 500 }}>
            סוג ערך:
          </Typography>
          <ButtonGroup variant='outlined' sx={{ bgcolor: 'background.default' }}>
            <Button
              variant={valueType === 'string' ? 'contained' : 'outlined'}
              onClick={() => onValueTypeChange('string')}
              sx={{ minWidth: 60 }}
            >
              טקסט
            </Button>
            <Button
              variant={valueType === 'number' ? 'contained' : 'outlined'}
              onClick={() => onValueTypeChange('number')}
              sx={{ minWidth: 60 }}
            >
              מספר
            </Button>
            <Button
              variant={valueType === 'boolean' ? 'contained' : 'outlined'}
              onClick={() => onValueTypeChange('boolean')}
              sx={{ minWidth: 70 }}
            >
              בוליאני
            </Button>
          </ButtonGroup>
        </Box>
      )}
      {renderInput()}
    </Box>
  )
}

export default SingleConditionValueInput
