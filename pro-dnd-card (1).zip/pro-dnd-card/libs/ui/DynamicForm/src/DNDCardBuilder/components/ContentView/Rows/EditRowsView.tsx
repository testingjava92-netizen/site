import React from 'react'
import ListIcon from '@mui/icons-material/List'
import LayoutIcon from '@mui/icons-material/ViewQuilt'
import MenuList, { MenuCategory } from '../MenuList'
import { useDNDCardBuilderContext } from '../../../utils/context'
import EditRowsCategory from './EditRowsCategory'
import { RowsCategoryType } from '../../../types'

const categories: MenuCategory[] = [
  { id: 'rows', label: 'שורות', icon: <ListIcon /> },
  { id: 'layout', label: 'פריסה', icon: <LayoutIcon /> }
]

const EditRowsView: React.FC = () => {
  const { categoryStates, updateRowsCategory } = useDNDCardBuilderContext()
  const selectedCategory = categoryStates.rows

  return (
    <>
      <MenuList
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={(categoryId) => updateRowsCategory(categoryId as RowsCategoryType)}
      />

      <EditRowsCategory selectedCategory={selectedCategory} />
    </>
  )
}

export default EditRowsView
