import { DNDCardBuilderContext } from '../utils/context'
import { useCardBuilderContextValues } from '../hooks/useCardBuilderContextValues '
import { DNDCardBuilderProviderProps } from '../types'

const DNDCardBuilderProvider = ({
  children,
  selectedCollection,
  setSelectedCollection,
  editingState,
  setEditingState
}: DNDCardBuilderProviderProps & { children: React.ReactNode }) => {
  const value = useCardBuilderContextValues({
    selectedCollection,
    setSelectedCollection,
    editingState,
    setEditingState
  })

  return <DNDCardBuilderContext.Provider value={value}>{children}</DNDCardBuilderContext.Provider>
}

export default DNDCardBuilderProvider
