import { useMemo } from 'react'
import { getHighlightStyles } from '../utils/utils'
import { EditingState, IFieldRow } from '../types'
import { useCardContext } from './useCardContext'
import { useTheme } from '@mui/material'

export const useRowHighlightStyles = ({ row, rowIndex }: { row: IFieldRow; rowIndex: number }) => {
  const { editingState } = useCardContext()
  const theme = useTheme()

  const isRowHighlighted = (_rowIndex: number, _editingState?: EditingState) =>
    !_editingState?.editingField && _rowIndex === _editingState?.editingRow?.rowIndex

  const isRowHovered = (rowId?: string, _editingState?: EditingState) =>
    !!rowId && rowId === _editingState?.hoveredItem?._id

  return useMemo(() => {
    const isHighlighted = isRowHighlighted(rowIndex, editingState)
    const isHovered = isRowHovered(row._id, editingState)

    return getHighlightStyles({ isHighlighted, isHovered, theme })
  }, [theme, rowIndex, row._id, editingState])
}
