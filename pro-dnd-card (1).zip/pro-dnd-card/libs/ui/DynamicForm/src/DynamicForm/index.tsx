import { FormProvider, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Card } from './components/Card'
import { ICollection, EditingState } from './types'
import { z } from 'zod'
import { DefaultSchema } from './types'
import { Box, Skeleton } from '@mui/material'
import { useEffect, useState, useCallback } from 'react'

// Session storage key for default values
const DEFAULT_VALUES_STORAGE_KEY = 'defaultValues'

// Helper functions for session storage
const getDefaultValuesFromStorage = (): DefaultSchema | null => {
  try {
    const item = sessionStorage.getItem(DEFAULT_VALUES_STORAGE_KEY)
    return item ? JSON.parse(item) : null
  } catch {
    return null
  }
}

const setDefaultValuesInStorage = (values: DefaultSchema | null): void => {
  try {
    if (values) {
      sessionStorage.setItem(DEFAULT_VALUES_STORAGE_KEY, JSON.stringify(values))
    } else {
      sessionStorage.removeItem(DEFAULT_VALUES_STORAGE_KEY)
    }
  } catch {
    // Silently fail if storage is not available
  }
}

export { CardHeader } from './components/CardHeader'
export type { EditingState } from './types'

export const DynamicForm = ({
  collection,
  editingState
}: {
  collection: ICollection | null
  editingState?: EditingState
}) => {
  const [defaultValues, setDefaultValues] = useState<DefaultSchema | undefined>(() => {
    return getDefaultValuesFromStorage() || undefined
  })

  const setDefaultValuesWithStorage = useCallback((values: DefaultSchema | undefined) => {
    setDefaultValues(values)
    setDefaultValuesInStorage(values || null)
  }, [])

  useEffect(() => {
    const fetchDefaultValues = async () => {
      const values = await collection?.schema.parseAsync({})

      setDefaultValuesWithStorage(values)
    }

    if (!defaultValues) {
      fetchDefaultValues()
    }
  }, [defaultValues, collection, setDefaultValuesWithStorage])

  return (
    <Box
      sx={{
        width: 500,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden'
      }}
    >
      {collection && defaultValues ? (
        <DynamicFormContent
          defaultValues={defaultValues}
          collection={collection}
          editingState={editingState}
        />
      ) : (
        <Skeleton variant='rectangular' height='100%' width='100%' />
      )}
    </Box>
  )
}

export const DynamicFormContent = <T extends DefaultSchema>({
  collection,
  defaultValues,
  editingState
}: {
  collection: ICollection<T>
  defaultValues: DefaultSchema
  editingState?: EditingState
}) => {
  const methods = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver:
      collection.name === 'Preview'
        ? undefined
        : zodResolver(collection.schema as z.ZodObject<Record<string, z.ZodTypeAny>>),
    defaultValues
  })

  const values = methods.watch()

  useEffect(() => {
    sessionStorage.setItem(DEFAULT_VALUES_STORAGE_KEY, JSON.stringify(values))
  }, [values])

  return (
    <FormProvider {...methods}>
      <Card collection={collection} editingState={editingState} />
    </FormProvider>
  )
}

export default DynamicForm
