// JSON-based condition system for serializable UI schemas
export enum ConditionOperator {
  EQUALS = 'equals',
  NOT_EQUALS = 'not_equals',
  GREATER_THAN = 'greater_than',
  LESS_THAN = 'less_than',
  GREATER_OR_EQUAL = 'greater_or_equal',
  LESS_OR_EQUAL = 'less_or_equal',
  CONTAINS = 'contains',
  NOT_CONTAINS = 'not_contains',
  IS_EMPTY = 'is_empty',
  IS_NOT_EMPTY = 'is_not_empty',
  IS_TRUE = 'is_true',
  IS_FALSE = 'is_false'
}

export enum LogicalOperator {
  AND = 'and',
  OR = 'or'
}

export enum WidthKey {
  W1 = 1,
  W2 = 2,
  W3 = 3,
  W4 = 4,
  W5 = 5,
  W6 = 6,
  W7 = 7,
  W8 = 8,
  W9 = 9,
  W10 = 10,
  W11 = 11,
  W12 = 12
}

// Unified sizing system for both height and gap
export enum SizeKey {
  S0 = 0,
  S1 = 1,
  S2 = 2,
  S3 = 3,
  S4 = 4,
  S5 = 5,
  S6 = 6,
  S7 = 7,
  S8 = 8,
  S9 = 9,
  S10 = 10,
  S11 = 11,
  S12 = 12,
  S13 = 13,
  S14 = 14,
  S15 = 15,
  S16 = 16,
  S17 = 17,
  S18 = 18,
  S19 = 19,
  S20 = 20,
  S21 = 21,
  S22 = 22,
  S23 = 23,
  S24 = 24,
  S25 = 25,
  S26 = 26,
  S27 = 27,
  S28 = 28,
  S29 = 29,
  S30 = 30,
  S31 = 31,
  S32 = 32,
  S33 = 33,
  S34 = 34,
  S35 = 35,
  S36 = 36,
  S37 = 37,
  S38 = 38,
  S39 = 39,
  S40 = 40
}

// Legacy type aliases for backward compatibility
export type HeightKey = SizeKey
export type GapKey = SizeKey

export enum IconType {
  CAR = 'car',
  BICYCLE = 'bicycle',
  LEGS = 'legs',
  HOME = 'home',
  SETTINGS = 'settings',
  PERSON = 'person',
  EMAIL = 'email',
  PHONE = 'phone',
  LOCATION = 'location',
  CALENDAR = 'calendar',
  SEARCH = 'search',
  ADD = 'add',
  EDIT = 'edit',
  DELETE = 'delete',
  SAVE = 'save',
  CANCEL = 'cancel',
  CHECK = 'check',
  CLOSE = 'close',
  INFO = 'info',
  WARNING = 'warning',
  ERROR = 'error',
  SUCCESS = 'success'
}

export enum FieldComponentType {
  inputText = 'input-text',
  inputNumber = 'input-number',
  inputEmail = 'input-email',
  inputPassword = 'input-password',
  inputUrl = 'input-url',
  inputCheckbox = 'input-checkbox',
  inputSwitch = 'input-switch',
  inputRadio = 'input-radio',
  inputDate = 'input-date',
  inputDateTime = 'input-date-time',
  inputDateRange = 'input-date-range',
  inputSlider = 'input-slider',

  textarea = 'textarea',
  select = 'select',
  buttonsGroup = 'buttons-group',
  chipsSelect = 'chips-select'
}

export enum LazyLoaderType {
  LOAD_DEPARTMENTS = 'loadDepartments',
  LOAD_PIRATES = 'loadPirates'
}

export enum RadioOrientation {
  VERTICAL = 'vertical',
  HORIZONTAL = 'horizontal'
}

export enum ConditionField {
  disabled = 'disabled',
  hidden = 'hidden'
}
