import {
  IconType,
  ConditionOperator,
  LogicalOperator,
  WidthKey,
  SizeKey,
  FieldComponentType,
  LazyLoaderType,
  RadioOrientation,
  ConditionField
} from './enums'
import { ViewType } from '../../DNDCardBuilder/types/enums'
import { CategoryStates } from '../../DNDCardBuilder/types/types'
import { z } from 'zod'

// Default constants

export type IOptionBadge = {
  text: string
  color?: 'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'
}

// Date range validation types
export type DayOfWeek = 0 | 1 | 2 | 3 | 4 | 5 | 6 // 0 = Sunday, 6 = Saturday

export type DateRangeValidationConfig = {
  // Past date restrictions
  minDaysFromToday?: number // 0 = today, 1 = tomorrow, etc. Default: 0
  // Day of week restrictions (array of allowed days)
  allowedDaysOfWeek?: DayOfWeek[]
}

export type DateRangeValidations = {
  startDate?: DateRangeValidationConfig
  endDate?: DateRangeValidationConfig
}

export type IOption<Schema = DefaultSchema> = {
  value: string | number | boolean
  label: string
  icon?: IconType // Icon enum key for JSON serialization
  isIconOnly?: boolean // Display only icon with label as tooltip (requires icon)
  badge?: IOptionBadge // Optional text badge for the button
  disabled?: boolean | Condition<Schema> // Static or conditional disabled state
  hidden?: boolean | Condition<Schema> // Static or conditional hidden state
}

export type DefaultSchema = Record<string, unknown>

// Type-safe paths with explicit support for common nested structures
// This provides better intellisense while allowing flexibility for nested paths
export type Paths<T> = T extends DefaultSchema
  ? keyof T extends string
    ? keyof T | `${keyof T}.${string}`
    : string
  : string

export type ConditionValue = string | number | boolean | null

export type SingleConditionField<Schema = DefaultSchema> = {
  field: Paths<Schema>
  isContext?: false
  operator: ConditionOperator
  value?: ConditionValue
  title?: string
}

export type SingleConditionContext = {
  field: string
  isContext: true
  operator: ConditionOperator
  value?: ConditionValue
  title?: string
}

export type SingleCondition<Schema = DefaultSchema> =
  | SingleConditionField<Schema>
  | SingleConditionContext

export type Condition<Schema = DefaultSchema> = SingleCondition<Schema> | ConditionGroup<Schema>

export type ConditionGroup<Schema = DefaultSchema> = {
  operator?: LogicalOperator
  conditions: Condition<Schema>[]
  title?: string
}

export type ILayoutBaseField<Schema = DefaultSchema> = {
  _id: string
  path: Paths<Schema>
  label?: string
  hidden?: boolean | Condition<Schema>
  disabled?: boolean | Condition<Schema>
  width?: WidthKey
  required?: boolean
}

export type IInputNumberLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component: FieldComponentType.inputNumber
  placeholder: string
  min?: number // Minimum value for number inputs
  max?: number // Maximum value for number inputs
}

export type IInputSliderLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component: FieldComponentType.inputSlider
  label: string
  min?: number // Minimum value for slider (default: 0)
  max?: number // Maximum value for slider (default: 100)
  step?: number // Step increment for slider (default: 1)
  showValue?: boolean // Show the current value (default: true)
  showMarks?: boolean // Show step marks on the slider (default: false)
}

export type IInputTextLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component:
    | FieldComponentType.inputText
    | FieldComponentType.inputEmail
    | FieldComponentType.inputPassword
    | FieldComponentType.inputUrl
    | FieldComponentType.textarea
  placeholder: string
  maxLength?: number // Maximum character length for text inputs
  showCharacterCounter?: boolean // Show character counter indicator
}

export type IInputLayoutField<Schema = DefaultSchema> =
  | IInputNumberLayoutField<Schema>
  | IInputSliderLayoutField<Schema>
  | IInputTextLayoutField<Schema>

export type ISelectLayoutFieldOptions<Schema = DefaultSchema> = {
  values?: Array<IOption<Schema>>
  lazyValues?: LazyLoaderType
  mapBoolean?: { true: string; false: string }
}

export type ISelectLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component:
    | FieldComponentType.select
    | FieldComponentType.buttonsGroup
    | FieldComponentType.chipsSelect
  options: ISelectLayoutFieldOptions<Schema>
  multiple?: boolean
  placeholder?: string
}

export type IRadioLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component: FieldComponentType.inputRadio
  options: ISelectLayoutFieldOptions<Schema>
  orientation?: RadioOrientation // Vertical or horizontal layout
}

export type IInputDateRangeLayoutField<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component: FieldComponentType.inputDateRange

  startDateLabel: string
  endDateLabel: string
  startDatePlaceholder: string
  endDatePlaceholder: string
  startDatePath: string
  endDatePath: string

  // Date range specific validations
  dateRangeValidations?: DateRangeValidations
}

export type IRestLayoutFields<Schema = DefaultSchema> = ILayoutBaseField<Schema> & {
  component:
    | FieldComponentType.inputCheckbox
    | FieldComponentType.inputSwitch
    | FieldComponentType.inputDate
    | FieldComponentType.inputDateTime
  placeholder?: string
}

export type ILayoutField<Schema = DefaultSchema> =
  | IInputLayoutField<Schema>
  | IRestLayoutFields<Schema>
  | ISelectLayoutField<Schema>
  | IRadioLayoutField<Schema>
  | IInputDateRangeLayoutField<Schema>

export interface IFieldRow<Schema = DefaultSchema> {
  _id: string
  fields: ILayoutField<Schema>[]
  gap?: SizeKey // Gap between fields (default: SizeKey.S0 = no gap)
  height?: SizeKey // Height of the row (default: SizeKey.S0 = 56px)
  hidden?: boolean | Condition<Schema>
  disabled?: boolean | Condition<Schema>
  title?: string // Optional title for the row
  collapsible?: boolean // Makes the row collapsible with expand/collapse functionality
  defaultExpanded?: boolean // Default expanded state when collapsible is true
}

export interface ICardSchemaMeta<Schema = DefaultSchema> {
  rows: IFieldRow<Schema>[]
  gap?: SizeKey
  px?: SizeKey // Horizontal padding (left/right)
  py?: SizeKey // Vertical padding (top/bottom)
  rowHeight?: SizeKey // Height of the row (default: SizeKey.S0 = 56px)
  context?: Record<string, unknown>
}

export type FieldComponentProps<T extends ILayoutBaseField = ILayoutBaseField> = {
  field: T
  rowHeight: string
  disabled?: boolean
}

export type FieldComponentMapper = {
  [FieldComponentType.inputText]: React.ComponentType<FieldComponentProps<IInputTextLayoutField>>
  [FieldComponentType.inputNumber]: React.ComponentType<
    FieldComponentProps<IInputNumberLayoutField>
  >
  [FieldComponentType.inputEmail]: React.ComponentType<FieldComponentProps<IInputTextLayoutField>>
  [FieldComponentType.inputPassword]: React.ComponentType<
    FieldComponentProps<IInputTextLayoutField>
  >
  [FieldComponentType.inputUrl]: React.ComponentType<FieldComponentProps<IInputTextLayoutField>>
  [FieldComponentType.textarea]: React.ComponentType<FieldComponentProps<IInputTextLayoutField>>
  [FieldComponentType.inputDate]: React.ComponentType<FieldComponentProps<IRestLayoutFields>>
  [FieldComponentType.inputDateTime]: React.ComponentType<FieldComponentProps<IRestLayoutFields>>
  [FieldComponentType.inputDateRange]: React.ComponentType<
    FieldComponentProps<IInputDateRangeLayoutField>
  >
  [FieldComponentType.inputSlider]: React.ComponentType<
    FieldComponentProps<IInputSliderLayoutField>
  >
  [FieldComponentType.select]: React.ComponentType<FieldComponentProps<ISelectLayoutField>>
  [FieldComponentType.chipsSelect]: React.ComponentType<FieldComponentProps<ISelectLayoutField>>
  [FieldComponentType.inputCheckbox]: React.ComponentType<FieldComponentProps<IRestLayoutFields>>
  [FieldComponentType.inputSwitch]: React.ComponentType<FieldComponentProps<IRestLayoutFields>>
  [FieldComponentType.buttonsGroup]: React.ComponentType<FieldComponentProps<ISelectLayoutField>>
  [FieldComponentType.inputRadio]: React.ComponentType<FieldComponentProps<IRadioLayoutField>>
}

export type UnknownRecord = Record<string, unknown>

export type ICollection<T extends DefaultSchema = DefaultSchema> = {
  name: string
  schema: z.ZodType<T>
  uiSchema: ICardSchemaMeta<T>
}
export interface EditingFieldInfo {
  rowIndex: number
  fieldIndex: number
}

export interface HoveredInfo {
  _id: string
}

export interface EditingRowInfo {
  rowIndex: number
}

export interface EditingOptionInfo {
  rowIndex: number
  fieldIndex: number
  optionIndex: number
}

export interface EditingConditionInfo {
  rowIndex: number
  fieldIndex?: number
  optionIndex?: number
  conditionIndexes?: number[]
  conditionField: ConditionField
}

export interface EditingState {
  editingField: EditingFieldInfo | null
  editingRow: EditingRowInfo | null
  hoveredItem: HoveredInfo | null
  editingOption: EditingOptionInfo | null
  editingCondition: EditingConditionInfo | null
  currentView: ViewType
  categoryStates: CategoryStates
}

export type CardContextType = {
  collection: ICollection
  editingState?: EditingState
}
