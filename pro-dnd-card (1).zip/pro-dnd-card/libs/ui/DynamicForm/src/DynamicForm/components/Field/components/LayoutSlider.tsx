import { Slider, Box, Typography } from '@mui/material'
import { FieldComponentProps, IInputSliderLayoutField } from '../../../types'
import { Controller, useFormContext } from 'react-hook-form'

const LayoutSlider = ({
  field,
  disabled = false
}: FieldComponentProps<IInputSliderLayoutField>) => {
  const { path, label, min = 0, max = 100, step = 1, showValue = true, showMarks = false } = field
  const { control } = useFormContext()

  // Generate marks for the slider if showMarks is enabled
  const generateMarks = () => {
    if (!showMarks) return false

    const marks = []
    for (let value = min; value <= max; value += step * 10) {
      marks.push({ value, label: value.toString() })
    }
    return marks
  }

  return (
    <Controller
      name={path}
      control={control}
      render={({ field: controllerField }) => {
        const currentValue = controllerField.value ?? min

        return (
          <Box sx={{ px: 2, py: 1, minWidth: 200 }}>
            <Box
              sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}
            >
              <Typography variant='body2' color='text.secondary'>
                {label}
              </Typography>
              {showValue && (
                <Typography variant='body2' fontWeight='medium' color='primary.main'>
                  {currentValue}
                </Typography>
              )}
            </Box>

            <Slider
              {...controllerField}
              value={currentValue}
              min={min}
              max={max}
              step={step}
              marks={generateMarks()}
              disabled={disabled}
              onChange={(_, value) => {
                controllerField.onChange(value)
              }}
              valueLabelDisplay='auto'
              sx={{
                '& .MuiSlider-thumb': {
                  boxShadow: 'none',
                  '&:hover, &.Mui-focusVisible': {
                    boxShadow: '0px 0px 0px 8px rgba(63, 81, 181, 0.16)'
                  }
                },
                '& .MuiSlider-track': {
                  border: 'none'
                },
                '& .MuiSlider-rail': {
                  opacity: 0.3
                }
              }}
            />

            {!showMarks && (
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                <Typography variant='caption' color='text.secondary'>
                  {min}
                </Typography>
                <Typography variant='caption' color='text.secondary'>
                  {max}
                </Typography>
              </Box>
            )}
          </Box>
        )
      }}
    />
  )
}

export default LayoutSlider
