import { Box, IconButton, InputAdornment, TextField, Typography } from '@mui/material'
import { useFormContext, Controller } from 'react-hook-form'
import {
  FieldComponentProps,
  FieldComponentType,
  IInputLayoutField,
  IInputNumberLayoutField,
  IInputTextLayoutField
} from '../../../types'
import { getInputType } from '../../../utils/utils'
import { Add, Remove } from '@mui/icons-material'

const LayoutTextField = ({
  field,
  rowHeight,
  disabled: externalDisabled = false
}: FieldComponentProps<IInputLayoutField>) => {
  const inputField = field
  const { path, label, component, placeholder, required } = inputField
  const type = getInputType(component)
  const { control } = useFormContext()

  // Type-safe property access
  const isNumberInput = component === FieldComponentType.inputNumber
  const numberField = isNumberInput ? (inputField as IInputNumberLayoutField) : null
  const textField = !isNumberInput ? (inputField as IInputTextLayoutField) : null

  // Calculate inputProps based on field type
  const getInputProps = (): Record<string, string | number> => {
    const props: Record<string, string | number> = {}

    if (isNumberInput && numberField) {
      // For number inputs, use min/max directly
      if (numberField.min !== undefined) props.min = numberField.min
      if (numberField.max !== undefined) props.max = numberField.max
    } else if (textField) {
      // For text inputs, use maxLength
      if (textField.maxLength !== undefined) props.maxLength = textField.maxLength
    }

    return props
  }

  // Helper function to get character counter text
  const getCharacterCounterText = (currentLength: number): string => {
    if (!textField) return `${currentLength}`

    const limit = textField.maxLength
    if (!limit) return `${currentLength}`
    return `${currentLength}/${limit}`
  }

  return (
    <Controller
      name={path}
      control={control}
      render={({ field, fieldState: { error } }) => {
        const isNumber = type === 'number'

        const getCurrentNumericValue = (): number => {
          const current = field.value
          if (typeof current === 'number') return current
          if (typeof current === 'string' && current.trim() !== '') {
            const parsed = parseFloat(current)
            return Number.isNaN(parsed) ? 0 : parsed
          }
          return 0
        }

        const clamp = (value: number): number => {
          if (!numberField) return value

          let result = value
          if (typeof numberField.min !== 'undefined') {
            result = Math.max(result, numberField.min)
          }
          if (typeof numberField.max !== 'undefined') {
            result = Math.min(result, numberField.max)
          }
          return result
        }

        const handleIncrement = () => {
          const next = clamp(getCurrentNumericValue() + 1)
          field.onChange(next)
        }
        const handleDecrement = () => {
          const next = clamp(getCurrentNumericValue() - 1)
          field.onChange(next)
        }

        const handleNumberBlur = (e: React.FocusEvent<HTMLInputElement>) => {
          if (isNumber && numberField) {
            const value = e.target.value
            if (value !== '' && !isNaN(parseFloat(value))) {
              const numValue = parseFloat(value)
              const clampedValue = clamp(numValue)

              // Only update if the value actually changed after clamping
              if (clampedValue !== numValue) {
                field.onChange(clampedValue)
              }
            }
          }
        }

        return (
          <Box
            sx={{
              position: 'relative',
              '& .number-stepper': {
                opacity: 0,
                transform: 'translateX(4px)',
                transition: 'opacity 150ms ease, transform 150ms ease'
              },
              '& .number-stepper.start': {
                transform: 'translateX(-4px)'
              },
              '&:hover .number-stepper': {
                opacity: 1,
                transform: 'translateX(0)'
              },
              // Hide native number spinners
              '& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button':
                {
                  WebkitAppearance: 'none',
                  margin: 0
                },
              '& input[type=number]': {
                MozAppearance: 'textfield'
              }
            }}
          >
            <Box sx={{ position: 'relative' }}>
              <TextField
                {...field}
                value={field.value ?? ''}
                label={label}
                type={type}
                multiline={component === FieldComponentType.textarea}
                rows={component === FieldComponentType.textarea ? 4 : 1}
                fullWidth
                required={required ?? false}
                disabled={externalDisabled}
                error={!!error}
                helperText={error?.message}
                variant='outlined'
                placeholder={placeholder}
                inputProps={getInputProps()}
                slotProps={{
                  inputLabel: {
                    shrink: true
                  },
                  input: {
                    sx: {
                      height: component === FieldComponentType.textarea ? undefined : rowHeight
                    },
                    ...(isNumber
                      ? {
                          startAdornment: (
                            <InputAdornment
                              position='start'
                              className='number-stepper start'
                              sx={{ '& .MuiSvgIcon-root': { fontSize: 16 }, mx: 0.125 }}
                            >
                              <IconButton
                                size='small'
                                edge='start'
                                aria-label='decrement'
                                onClick={(e) => {
                                  e.preventDefault()
                                  e.stopPropagation()
                                  handleDecrement()
                                }}
                                disabled={externalDisabled}
                                sx={{ p: 0.25 }}
                              >
                                <Remove fontSize='inherit' />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: (
                            <InputAdornment
                              position='end'
                              className='number-stepper end'
                              sx={{ '& .MuiSvgIcon-root': { fontSize: 16 }, mx: 0.125 }}
                            >
                              <IconButton
                                size='small'
                                edge='end'
                                aria-label='increment'
                                onClick={(e) => {
                                  e.preventDefault()
                                  e.stopPropagation()
                                  handleIncrement()
                                }}
                                disabled={externalDisabled}
                                sx={{ p: 0.25 }}
                              >
                                <Add fontSize='inherit' />
                              </IconButton>
                            </InputAdornment>
                          )
                        }
                      : {})
                  }
                }}
                onChange={(e) => {
                  const value = e.target.value
                  if (isNumber) {
                    if (value === '') {
                      field.onChange(undefined)
                    } else {
                      const numValue = parseFloat(value)
                      field.onChange(Number.isNaN(numValue) ? value : numValue)
                    }
                  } else {
                    field.onChange(value)
                  }
                }}
                onBlur={isNumber ? handleNumberBlur : undefined}
              />
            </Box>

            {/* Character counter - positioned below the input */}
            {textField?.showCharacterCounter && !isNumberInput && (
              <Typography
                variant='caption'
                sx={{
                  position: 'absolute',
                  right: 10,
                  bottom: -10,
                  backgroundColor: 'background.default',
                  display: 'block',
                  textAlign: 'right',
                  color: 'text.secondary',
                  fontSize: '0.75rem',
                  mt: 0.5,
                  px: 1
                }}
              >
                {getCharacterCounterText(String(field.value ?? '').length)}
              </Typography>
            )}
          </Box>
        )
      }}
    />
  )
}

export default LayoutTextField
