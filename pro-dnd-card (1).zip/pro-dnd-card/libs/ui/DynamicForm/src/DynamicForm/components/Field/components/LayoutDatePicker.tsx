import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns'
import { useFormContext, Controller } from 'react-hook-form'
import { FieldComponentProps, IRestLayoutFields } from '../../../types'
import { DEFAULT_DATE_FORMAT } from '../../../../DNDCardBuilder/constants'

const LayoutDatePicker = ({
  field,
  rowHeight,
  disabled = false
}: FieldComponentProps<IRestLayoutFields>) => {
  const { path, label } = field
  const { control } = useFormContext()

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Controller
        name={path}
        control={control}
        render={({ field, fieldState: { error } }) => (
          <DatePicker
            {...field}
            value={field.value || null}
            onChange={(newValue) => field.onChange(newValue)}
            disabled={disabled}
            format={DEFAULT_DATE_FORMAT}
            slotProps={{
              textField: {
                label: label,
                fullWidth: true,
                error: !!error,
                helperText: error?.message,
                variant: 'outlined',
                disabled: disabled,
                InputLabelProps: {
                  shrink: true
                },
                InputProps: {
                  sx: {
                    height: rowHeight
                  }
                }
              }
            }}
          />
        )}
      />
    </LocalizationProvider>
  )
}

export default LayoutDatePicker
