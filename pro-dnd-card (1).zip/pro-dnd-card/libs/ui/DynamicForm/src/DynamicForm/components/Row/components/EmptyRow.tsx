import { Box, Typography } from '@mui/material'
import { IFieldRow } from '../../../types'
import { useRowHighlightStyles } from '../../../hooks/useRowHighlightStyles'

const EmptyRow = ({
  row,
  rowIndex,
  rowHeight,
  highlightStyles
}: {
  row: IFieldRow
  rowIndex: number
  rowHeight: string
  highlightStyles?: ReturnType<typeof useRowHighlightStyles>
}) => {
  return (
    <Box
      data-row-index={rowIndex}
      sx={{
        mb: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: '1px dashed',
        borderColor: 'divider',
        borderRadius: 1,
        color: 'text.secondary',
        height: rowHeight,
        ...highlightStyles
      }}
    >
      <Typography variant='body2' sx={{ fontStyle: 'italic' }}>
        {row.title || 'שורה ריקה'} - אין שדות בשורה זו
      </Typography>
    </Box>
  )
}

export default EmptyRow
