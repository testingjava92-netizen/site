import React from 'react'
import Header from './Header'
import { Box } from '@mui/material'

const CollectionsWrapper = ({ children, title }: { children: React.ReactNode; title: string }) => {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      <Header title={title} />

      {children}
    </Box>
  )
}

export default CollectionsWrapper
