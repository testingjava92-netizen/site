import { EditingState } from '@pro3/DynamicForm'
import { ICollection } from '@pro3/DynamicForm'
import { createContext, Dispatch, SetStateAction } from 'react'

export type CollectionsContextType = {
  collections?: ICollection[]
  isLoading: boolean
  selectedCollection: ICollection | null
  setSelectedCollection: Dispatch<SetStateAction<ICollection | null>>
  editingState: EditingState
  setEditingState: (state: EditingState) => void
  previewCollection?: ICollection
}

export const CollectionsContext = createContext<CollectionsContextType>(
  {} as CollectionsContextType
)
