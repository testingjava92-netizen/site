import { Box, Paper, SxProps, Typography } from '@mui/material'
import DynamicForm, { DNDCardBuilder, ICollection } from '@pro3/DynamicForm'
import { SetStateAction, Dispatch, useContext } from 'react'
import CollectionsWrapper from '../CollectionsWrapper/CollectionsWrapper'
import CollectionsProvider from '../CollectionsWrapper/CollectionsProvider'
import { CollectionsContext } from '../CollectionsWrapper/CollectionsContext'

const Panel = ({
  title,
  children,
  sx
}: {
  title: string
  children: React.ReactNode
  sx?: SxProps
}) => (
  <Paper
    sx={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: 'none',
      background: 'transparent',
      minWidth: 0,
      justifyContent: 'center',
      alignSelf: 'flex-start',
      maxHeight: '100%',
      height: '100%',
      overflow: 'hidden',
      ...sx
    }}
  >
    <Box
      p={2}
      sx={{
        borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
        flexShrink: 0,
        alignItems: 'center'
      }}
    >
      <Typography variant='h6'>{title}</Typography>
    </Box>

    <Box
      p={2}
      sx={{
        overflow: 'hidden',
        flex: 1,
        width: '100%',
        justifyContent: 'center',
        display: 'flex'
      }}
    >
      {children}
    </Box>
  </Paper>
)

const DNDCardContent = () => {
  const {
    editingState,
    setEditingState,
    previewCollection,
    selectedCollection,
    setSelectedCollection
  } = useContext(CollectionsContext)

  return (
    <Box
      sx={{
        display: 'flex',
        gap: 4,
        alignItems: 'flex-start',
        justifyContent: 'center',
        flex: 1,
        overflow: 'hidden'
      }}
    >
      <Panel
        title='בילדר'
        sx={{
          width: {
            xs: '350px',
            sm: '450px',
            md: '550px',
            lg: '650px',
            xl: '800px'
          }
        }}
      >
        <DNDCardBuilder
          key={selectedCollection?.name ?? ''}
          setSelectedCollection={setSelectedCollection as Dispatch<SetStateAction<ICollection>>}
          selectedCollection={selectedCollection}
          editingState={editingState}
          setEditingState={setEditingState}
        />
      </Panel>

      <Panel title='תצוגה מקדימה'>
        <DynamicForm collection={previewCollection ?? null} editingState={editingState} />
      </Panel>
    </Box>
  )
}

const DNDCard = () => {
  return (
    <CollectionsProvider>
      <CollectionsWrapper title='עיצוב כרטיס'>
        <DNDCardContent />
      </CollectionsWrapper>
    </CollectionsProvider>
  )
}

export default DNDCard
